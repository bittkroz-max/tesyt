import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Clock, Calendar, BookOpen, Leaf, Zap, Shield, TrendingUp, Coins, Sprout, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const categoryIcons = {
  Beginners: BookOpen,
  Intermediate: Zap,
  Advanced: TrendingUp,
  Blockchain: Shield,
  DeFi: Coins,
  Sustainability: Leaf,
  Anfänger: BookOpen,
  Nachhaltigkeit: Leaf,
};

const categoryColors = {
  Beginners: 'badge-principianti',
  Intermediate: 'badge-intermedio',
  Advanced: 'badge-avanzato',
  Blockchain: 'badge-blockchain',
  DeFi: 'badge-defi',
  Sustainability: 'badge-sostenibilita',
  Anfänger: 'badge-principianti',
  Nachhaltigkeit: 'badge-sostenibilita',
};

const difficultyColors = {
  Easy: 'bg-secondary/15 text-secondary border-secondary/30',
  Medium: 'bg-blue-500/15 text-blue-500 border-blue-500/30',
  Hard: 'bg-orange-500/15 text-orange-500 border-orange-500/30',
  Einfach: 'bg-secondary/15 text-secondary border-secondary/30',
  Mittel: 'bg-blue-500/15 text-blue-500 border-blue-500/30',
};

const GuideCard = ({ guide, index }) => {
  const { t } = useLanguage();
  const [isHovered, setIsHovered] = useState(false);
  const CategoryIcon = categoryIcons[guide.category] || Sprout;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -6 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="h-full"
    >
      <Link to={guide.slug ? `/guides/${guide.slug}` : '/guides'} className="block h-full group" aria-label={`${t('Mehr erfahren über', 'Read more about')} ${guide.title}`}>
        <Card className="h-full overflow-hidden bg-card border-border transition-all duration-300 group-hover:shadow-2xl group-hover:shadow-primary/10 group-hover:border-primary/40 cursor-pointer">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between mb-3">
              <motion.div
                animate={{ rotate: isHovered ? 360 : 0 }}
                transition={{ duration: 0.6, ease: 'easeInOut' }}
                className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center transition-colors duration-300 group-hover:bg-primary/20"
              >
                <CategoryIcon className="w-6 h-6 text-primary" />
              </motion.div>
              <Badge className={`${categoryColors[guide.category] || 'badge-principianti'} text-xs font-medium`}>
                {guide.category}
              </Badge>
            </div>
            <h3 className="text-xl font-bold leading-tight mb-2 transition-colors duration-300 group-hover:text-primary">
              {guide.title}
            </h3>
            <p className="text-sm leading-relaxed line-clamp-3">
              {guide.description}
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <Badge className={`${difficultyColors[guide.difficulty] || difficultyColors.Easy} text-xs border`}>
                {guide.difficulty}
              </Badge>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{guide.readingTime} {t('Min. Lesezeit', 'min read')}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>{guide.date}</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-sm font-medium text-primary pt-1">
              <span className="transition-all duration-300 group-hover:mr-1">{t('Leitfaden lesen', 'Read Guide')}</span>
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
};

export default GuideCard;
