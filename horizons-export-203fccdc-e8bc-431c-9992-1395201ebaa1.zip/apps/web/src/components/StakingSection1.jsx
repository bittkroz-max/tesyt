import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const StakingSection1 = () => {
  const { t } = useLanguage();
  return (
    <section className="py-12 md:py-14 bg-gradient-to-br from-background via-muted/30 to-background border-y border-border">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            style={{ letterSpacing: '-0.02em' }}
          >
            {t('Einfach Assets staken für zusätzliche Renditechancen', 'Easily stake assets for additional yield opportunities')}
          </h2>
          <p className="text-xl font-semibold mb-4 text-primary">
            {t('Belohnungen direkt in Prime verdienen', 'Earn rewards directly in Prime')}
          </p>
          <p className="text-lg leading-relaxed mb-8 max-w-prose mx-auto">
            {t('Verdienen Sie Belohnungen auf Ihre Assets, ohne sie aus dem Vault-Speicher zu entfernen. Staken Sie Ihre Krypto-Bestände und sehen Sie Ihrem Portfolio beim Wachsen zu – mit wettbewerbsfähigen APY-Raten bei voller Sicherheit und Kontrolle.', 'Earn rewards on your assets without removing them from Vault storage. Stake your crypto holdings and watch your portfolio grow with competitive APY rates while maintaining full security and control.')}
          </p>
          <Button
            size="lg"
            className="gap-2 transition-all duration-200 active:scale-[0.98]"
          >
            {t('Staking starten', 'Start Staking')}
            <ArrowRight className="w-5 h-5" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default StakingSection1;
