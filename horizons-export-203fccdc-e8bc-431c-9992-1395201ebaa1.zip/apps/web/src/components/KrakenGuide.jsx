import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, ChevronLeft, ChevronRight, Copy, Check, ShieldAlert, ExternalLink,
  UserPlus, BadgeCheck, CreditCard, Bitcoin, ClipboardCopy, Send,
  Network, FileCheck2, CheckCircle2, AlertTriangle, Lock, Eye, Smartphone,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const KRAKEN_MOBILE_URL = 'https://app.kraken.com/JDNW';
const KRAKEN_SIGNUP_URL = 'https://www.kraken.com/sign-up';
const KRAKEN_BUY_URL = 'https://www.kraken.com/buy';
const KRAKEN_SUPPORT_URL = 'https://support.kraken.com';

/* ---------------- Illustrations (SVG / icon-based mockups) ---------------- */

const PhoneFrame = ({ children, label }) => (
  <div className="flex flex-col items-center">
    <div className="relative w-full max-w-[230px]">
      <div className="rounded-[2rem] border-2 border-border bg-card p-2 shadow-lg">
        <div className="rounded-[1.4rem] bg-background overflow-hidden">
          <div className="h-5 bg-primary/10 flex items-center justify-center">
            <div className="w-12 h-1 rounded-full bg-primary/30" />
          </div>
          <div className="p-3 min-h-[180px] flex flex-col items-center justify-center text-center">
            {children}
          </div>
        </div>
      </div>
      {label && <p className="text-xs text-muted-foreground mt-2 text-center">{label}</p>}
    </div>
  </div>
);

const KrakenLogo = ({ className = 'w-7 h-7' }) => (
  <div className={`${className} rounded-2xl bg-primary/15 flex items-center justify-center`}>
    <Bitcoin className="w-4 h-5 text-primary" />
  </div>
);

const Illustration1 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2"
    >
      <div className="w-14 h-14 rounded-2xl bg-primary/15 flex items-center justify-center">
        <Smartphone className="w-7 h-7 text-primary" />
      </div>
      <div className="flex gap-2">
        <div className="w-10 h-14 rounded-lg bg-muted flex items-center justify-center">
          <span className="text-[8px] text-muted-foreground font-semibold">App Store</span>
        </div>
        <div className="w-10 h-14 rounded-lg bg-muted flex items-center justify-center">
          <span className="text-[8px] text-muted-foreground font-semibold">Google Play</span>
        </div>
      </div>
      <motion.div
        animate={{ y: [0, -3, 0] }}
        transition={{ duration: 1.6, repeat: Infinity }}
        className="w-full h-8 bg-primary rounded-lg flex items-center justify-center"
      >
        <span className="text-[10px] text-primary-foreground font-semibold">Kraken</span>
      </motion.div>
    </motion.div>
  </PhoneFrame>
);

const Illustration2 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <KrakenLogo className="w-14 h-14" />
      <div className="w-full h-8 bg-muted rounded-lg flex items-center px-2">
        <span className="text-[10px] text-muted-foreground">E-Mail-Adresse</span>
      </div>
      <div className="w-full h-8 bg-muted rounded-lg flex items-center px-2">
        <span className="text-[10px] text-muted-foreground">Passwort festlegen</span>
      </div>
      <div className="w-full h-8 bg-primary rounded-lg flex items-center justify-center">
        <span className="text-[10px] text-primary-foreground font-semibold">Konto erstellen</span>
      </div>
    </motion.div>
  </PhoneFrame>
);

const Illustration3 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <div className="w-14 h-14 rounded-2xl bg-secondary/15 flex items-center justify-center">
        <BadgeCheck className="w-7 h-7 text-secondary" />
      </div>
      <div className="w-full bg-muted/50 rounded-lg p-2 flex items-center gap-2">
        <CreditCard className="w-4 h-4 text-primary" />
        <span className="text-[10px]">Ausweis scannen</span>
      </div>
      <div className="w-full bg-muted/50 rounded-lg p-2 flex items-center gap-2">
        <CreditCard className="w-4 h-4 text-primary" />
        <span className="text-[10px]">Gesichtsscan</span>
      </div>
      <motion.div
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 1.8, repeat: Infinity }}
        className="text-[10px] text-secondary font-semibold"
      >
        Verifizierung läuft …
      </motion.div>
    </motion.div>
  </PhoneFrame>
);

const Illustration4 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <div className="w-14 h-14 rounded-2xl bg-primary/15 flex items-center justify-center">
        <Bitcoin className="w-7 h-7 text-primary" />
      </div>
      <div className="w-full bg-muted/50 rounded-lg p-2 flex items-center justify-between">
        <span className="text-[10px] font-semibold">BTC</span>
        <span className="text-[10px] text-secondary">€ 100,00</span>
      </div>
      <motion.div
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 1.6, repeat: Infinity }}
        className="w-full h-8 bg-primary rounded-lg flex items-center justify-center"
      >
        <span className="text-[10px] text-primary-foreground font-semibold">Bitcoin kaufen</span>
      </motion.div>
    </motion.div>
  </PhoneFrame>
);

const Illustration5 = ({ address, copied, onCopy, label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <div className="w-12 h-12 rounded-xl bg-secondary/15 flex items-center justify-center">
        <ClipboardCopy className="w-6 h-6 text-secondary" />
      </div>
      <div className="w-full bg-muted rounded-lg p-2">
        <p className="text-[9px] text-muted-foreground mb-1">Ihre BTC-Adresse</p>
        <code className="text-[8px] break-all leading-tight">{address}</code>
      </div>
      <button
        onClick={onCopy}
        className="w-full h-8 bg-primary rounded-lg flex items-center justify-center gap-1"
      >
        {copied ? <Check className="w-3 h-3 text-primary-foreground" /> : <Copy className="w-3 h-3 text-primary-foreground" />}
        <span className="text-[10px] text-primary-foreground font-semibold">{copied ? 'Kopiert!' : 'Adresse kopieren'}</span>
      </button>
    </motion.div>
  </PhoneFrame>
);

const Illustration6 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center">
        <Send className="w-6 h-6 text-primary" />
      </div>
      <div className="w-full bg-muted/50 rounded-lg p-2 flex items-center justify-between">
        <span className="text-[10px]">Bitcoin (BTC)</span>
        <span className="text-[10px] text-muted-foreground">Abheben</span>
      </div>
      <motion.div
        animate={{ x: [0, 4, 0] }}
        transition={{ duration: 1.4, repeat: Infinity }}
        className="w-full h-8 bg-primary rounded-lg flex items-center justify-center"
      >
        <span className="text-[10px] text-primary-foreground font-semibold">Abheben</span>
      </motion.div>
    </motion.div>
  </PhoneFrame>
);

const Illustration7 = ({ address, copied, onCopy, label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <div className="w-12 h-12 rounded-xl bg-secondary/15 flex items-center justify-center">
        <Network className="w-6 h-6 text-secondary" />
      </div>
      <div className="w-full bg-muted rounded-lg p-2">
        <p className="text-[9px] text-muted-foreground mb-1">Empfängeradresse</p>
        <code className="text-[8px] break-all leading-tight">{address}</code>
      </div>
      <div className="w-full bg-secondary/10 rounded-lg p-2 flex items-center gap-1.5">
        <CheckCircle2 className="w-3 h-3 text-secondary" />
        <span className="text-[9px] text-secondary font-semibold">Netzwerk: Bitcoin (BTC)</span>
      </div>
      <button
        onClick={onCopy}
        className="w-full h-7 bg-muted/50 rounded-lg flex items-center justify-center gap-1"
      >
        <Copy className="w-3 h-3 text-muted-foreground" />
        <span className="text-[9px] text-muted-foreground">Erneut kopieren</span>
      </button>
    </motion.div>
  </PhoneFrame>
);

const Illustration8 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center">
        <FileCheck2 className="w-6 h-6 text-primary" />
      </div>
      <div className="w-full space-y-1">
        <div className="flex justify-between text-[9px]"><span className="text-muted-foreground">Betrag</span><span className="font-semibold">0,0015 BTC</span></div>
        <div className="flex justify-between text-[9px]"><span className="text-muted-foreground">Netzwerkgebühr</span><span>≈ 0,00005 BTC</span></div>
        <div className="flex justify-between text-[9px] border-t border-border pt-1"><span className="text-muted-foreground">Gesamt</span><span className="font-semibold">0,00155 BTC</span></div>
      </div>
      <motion.div
        animate={{ scale: [1, 1.05, 1] }}
        transition={{ duration: 1.6, repeat: Infinity }}
        className="w-full h-8 bg-primary rounded-lg flex items-center justify-center"
      >
        <span className="text-[10px] text-primary-foreground font-semibold">Abhebung bestätigen</span>
      </motion.div>
    </motion.div>
  </PhoneFrame>
);

const Illustration9 = ({ label }) => (
  <PhoneFrame label={label}>
    <motion.div
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center gap-2 w-full"
    >
      <motion.div
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ duration: 1.4, repeat: Infinity }}
        className="w-14 h-14 rounded-full bg-secondary/15 flex items-center justify-center"
      >
        <CheckCircle2 className="w-8 h-8 text-secondary" />
      </motion.div>
      <p className="text-[10px] font-semibold">Überweisung eingegangen</p>
      <div className="w-full bg-muted/50 rounded-lg p-2 flex items-center justify-between">
        <span className="text-[9px]">Bestätigungen</span>
        <span className="text-[9px] text-secondary font-semibold">3 / 3 ✓</span>
      </div>
      <p className="text-[8px] text-muted-foreground">In der delfinitx Wallet unter „Verlauf" sichtbar</p>
    </motion.div>
  </PhoneFrame>
);

/* ---------------- Step definitions ---------------- */

const buildSteps = (t, address, copied, onCopy) => [
  {
    icon: Smartphone,
    title: t('Kraken App herunterladen', 'Download the Kraken app'),
    body: (
      <>
        <p>{t(
          'Laden Sie die offizielle Kraken App aus dem Apple App Store oder Google Play Store herunter. Öffnen Sie nach der Installation die App.',
          'Download the official Kraken app from the Apple App Store or Google Play Store. After installation, open the app.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Achten Sie auf den Entwickler „Kraken" und die Bewertungen.', 'Look for the developer "Kraken" and check the ratings.')}</li>
          <li>{t('Installieren Sie keine Apps aus unbekannten Quellen.', 'Do not install apps from unknown sources.')}</li>
        </ul>
        <Button asChild className="w-full mt-3 gap-2">
          <a href={KRAKEN_MOBILE_URL} target="_blank" rel="noopener noreferrer">
            <Smartphone className="w-4 h-4" /> {t('Zur Kraken App', 'Get the Kraken app')}
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </Button>
      </>
    ),
    illustration: <Illustration1 label={t('Kraken App installieren', 'Install the Kraken app')} />,
  },
  {
    icon: UserPlus,
    title: t('Kraken Konto registrieren', 'Register a Kraken account'),
    body: (
      <>
        <p>{t(
          'Öffnen Sie die App oder besuchen Sie kraken.com und tippen Sie auf „Registrieren" / „Sign up". Geben Sie Ihre E-Mail-Adresse an, legen Sie ein starkes, einzigartiges Passwort fest und aktivieren Sie die Zwei-Faktor-Authentifizierung (2FA).',
          'Open the app or visit kraken.com and tap "Sign up". Enter your email address, set a strong, unique password, and enable two-factor authentication (2FA).',
        )}</p>
        <div className="mt-3 rounded-xl border border-secondary/20 bg-secondary/5 p-3">
          <p>{t(
            'Hinweis zur Kontoart: Für die private Nutzung ist ein Privatkonto in der Regel die einfachere und schnellere Wahl. Bei einem Geschäftskonto kann die Prüfung aufwendiger sein und länger dauern. Die Anforderungen und Bearbeitungszeiten von Kraken können sich ändern; maßgeblich sind die aktuellen Angaben von Kraken.',
            'Account type note: For personal use, an individual account is usually the simpler and faster choice. A business account may involve a more extensive and longer review. Kraken\'s requirements and processing times may change; the current information provided by Kraken is authoritative.',
          )}</p>
        </div>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Bestätigen Sie Ihre E-Mail-Adresse über den erhaltenen Link.', 'Confirm your email address via the link you receive.')}</li>
          <li>{t('Aktivieren Sie 2FA (z. B. Authenticator-App) für maximale Sicherheit.', 'Enable 2FA (e.g. an authenticator app) for maximum security.')}</li>
        </ul>
        <Button asChild className="w-full mt-3 gap-2">
          <a href={KRAKEN_SIGNUP_URL} target="_blank" rel="noopener noreferrer">
            <UserPlus className="w-4 h-4" /> {t('Kraken Konto erstellen', 'Create a Kraken account')}
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </Button>
      </>
    ),
    illustration: <Illustration2 label={t('Kraken Konto erstellen', 'Create a Kraken account')} />,
  },
  {
    icon: BadgeCheck,
    title: t('Identität verifizieren (KYC)', 'Verify your identity (KYC)'),
    body: (
      <>
        <p>{t(
          'Kraken führt eine Identitätsprüfung (KYC) durch, um gesetzliche Vorgaben zu erfüllen. Laden Sie ein Ausweisdokument hoch und schließen Sie die Verifizierung ab — meist inklusive eines kurzen Gesichtsscans.',
          'Kraken performs an identity verification (KYC) to meet legal requirements. Upload an identity document and complete the verification — usually including a short facial scan.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Wählen Sie den für Ihre Bedürfnisse passenden Verifizierungsgrad (z. B. „Intermediate").', 'Choose the verification level that fits your needs (e.g. "Intermediate").')}</li>
          <li>{t('Stellen Sie sicher, dass die Dokumente gut lesbar sind.', 'Make sure your documents are clearly legible.')}</li>
          <li>{t('Die Freischaltung erfolgt meist innerhalb weniger Minuten bis Stunden.', 'Approval usually takes a few minutes to a few hours.')}</li>
        </ul>
      </>
    ),
    illustration: <Illustration3 label={t('Identität verifizieren', 'Verify your identity')} />,
  },
  {
    icon: Bitcoin,
    title: t('Bitcoin kaufen', 'Buy Bitcoin'),
    body: (
      <>
        <p>{t(
          'Fügen Sie in Kraken eine Zahlungsmethode hinzu (z. B. Banküberweisung, Karte). Wählen Sie anschließend Bitcoin (BTC), geben Sie den gewünschten Euro-Betrag ein und schließen Sie den Kauf ab.',
          'Add a payment method in Kraken (e.g. bank transfer, card). Then select Bitcoin (BTC), enter the desired euro amount, and complete the purchase.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Die gekauften Bitcoin landen in Ihrem Kraken-Konto.', 'The purchased Bitcoin is credited to your Kraken account.')}</li>
          <li>{t('Sie können nun einen Teil oder den gesamten Betrag an delfinitx überweisen.', 'You can now transfer part or all of it to delfinitx.')}</li>
        </ul>
        <Button asChild className="w-full mt-3 gap-2">
          <a href={KRAKEN_BUY_URL} target="_blank" rel="noopener noreferrer">
            <Bitcoin className="w-4 h-4" /> {t('Jetzt Bitcoin kaufen', 'Buy Bitcoin now')}
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </Button>
      </>
    ),
    illustration: <Illustration4 label={t('Bitcoin auswählen & kaufen', 'Select Bitcoin & buy')} />,
  },
  {
    icon: ClipboardCopy,
    title: t('delfinitx Empfangsadresse kopieren', 'Copy your delfinitx receiving address'),
    body: (
      <>
        <p>{t(
          'In Ihrer delfinitx Wallet tippen Sie auf „Empfangen". Es wird Ihre persönliche Bitcoin-Empfangsadresse angezeigt.',
          'In your delfinitx wallet, tap "Receive". Your personal Bitcoin receiving address is shown.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Tippen Sie auf das Kopier-Symbol, um die vollständige Adresse zu kopieren.', 'Tap the copy icon to copy the full address.')}</li>
          <li>{t('Kopieren Sie immer die gesamte Adresse — niemals nur einen Teil.', 'Always copy the entire address — never just a part of it.')}</li>
        </ul>
        <div className="mt-3 bg-muted rounded-xl p-3">
          <p className="text-xs text-muted-foreground mb-1">{t('Ihre BTC-Empfangsadresse:', 'Your BTC receiving address:')}</p>
          <code className="text-[11px] break-all leading-tight block">{address}</code>
        </div>
      </>
    ),
    illustration: <Illustration5 address={address} copied={copied} onCopy={onCopy} label={t('Empfangsadresse in delfinitx kopieren', 'Copy receiving address in delfinitx')} />,
  },
  {
    icon: Send,
    title: t('Abhebung in Kraken starten', 'Start the withdrawal in Kraken'),
    body: (
      <>
        <p>{t(
          'Gehen Sie in Kraken zu Ihrem Bitcoin-Bestand und wählen Sie „Abheben" / „Withdraw".',
          'In Kraken, go to your Bitcoin balance and select "Withdraw".',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Wählen Sie als Währung Bitcoin (BTC).', 'Select Bitcoin (BTC) as the currency.')}</li>
          <li>{t('Wählen Sie die Option „An eine Krypto-Adresse abheben" / „On-chain".', 'Choose the option to withdraw "to a crypto address" / "On-chain".')}</li>
        </ul>
      </>
    ),
    illustration: <Illustration6 label={t('In Kraken „Abheben" wählen', 'Select "Withdraw" in Kraken')} />,
  },
  {
    icon: Network,
    title: t('Adresse einfügen & Netzwerk prüfen', 'Paste the address & verify the network'),
    body: (
      <>
        <p>{t(
          'Fügen Sie die kopierte delfinitx-Adresse in das Empfängerfeld ein.',
          'Paste the copied delfinitx address into the recipient field.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Netzwerk: Stellen Sie sicher, dass „Bitcoin (BTC)" ausgewählt ist — niemals andere Netzwerke.', 'Network: Make sure "Bitcoin (BTC)" is selected — never other networks.')}</li>
          <li>{t('Adresse vergleichen: Prüfen Sie die ersten und letzten Zeichen der eingefügten Adresse gegen die delfinitx-Adresse.', 'Compare the address: Check the first and last characters of the pasted address against the delfinitx address.')}</li>
        </ul>
      </>
    ),
    illustration: <Illustration7 address={address} copied={copied} onCopy={onCopy} label={t('Adresse einfügen & Netzwerk prüfen', 'Paste address & verify network')} />,
  },
  {
    icon: FileCheck2,
    title: t('Betrag & Gebühren prüfen, bestätigen', 'Review amount & fees, then confirm'),
    body: (
      <>
        <p>{t(
          'Geben Sie den zu überweisenden Bitcoin-Betrag ein. Kraken zeigt Ihnen die Netzwerkgebühr und den Gesamtbetrag an.',
          'Enter the Bitcoin amount to withdraw. Kraken displays the network fee and the total amount.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Prüfen Sie Betrag, Gebühr und Empfängeradresse ein letztes Mal.', 'Review the amount, fee, and recipient address one last time.')}</li>
          <li>{t('Bestätigen Sie die Transaktion — ggf. mit 2FA.', 'Confirm the transaction — with 2FA if required.')}</li>
        </ul>
      </>
    ),
    illustration: <Illustration8 label={t('Betrag & Gebühren prüfen, bestätigen', 'Review amount & fees, confirm')} />,
  },
  {
    icon: CheckCircle2,
    title: t('Transfer überprüfen', 'Verify the transfer'),
    body: (
      <>
        <p>{t(
          'Nach der Bestätigung wird die Transaktion im Bitcoin-Netzwerk verarbeitet. Je nach Netzwerkauslastung kann dies einige Minuten bis zu einer Stunde dauern.',
          'After confirmation, the transaction is processed on the Bitcoin network. Depending on network load, this can take a few minutes to about an hour.',
        )}</p>
        <ul className="list-disc pl-5 space-y-1 mt-2">
          <li>{t('Sobald ausreichend Bestätigungen vorliegen, erscheint der Eingang in Ihrer delfinitx Wallet.', 'Once enough confirmations are reached, the incoming funds appear in your delfinitx wallet.')}</li>
          <li>{t('Den Status können Sie im Verlauf Ihrer delfinitx Wallet einsehen.', 'You can check the status in the history of your delfinitx wallet.')}</li>
        </ul>
      </>
    ),
    illustration: <Illustration9 label={t('Transfer in delfinitx überprüfen', 'Verify the transfer in delfinitx')} />,
  },
];

/* ---------------- Security guidance ---------------- */
const SecurityNotes = ({ t }) => (
  <div className="bg-primary/5 border border-primary/20 rounded-2xl p-5 space-y-3">
    <div className="flex items-center gap-2">
      <ShieldAlert className="w-5 h-5 text-primary" />
      <h4 className="font-bold text-primary">{t('Wichtige Sicherheitshinweise', 'Important security notes')}</h4>
    </div>
    <ul className="space-y-2 text-sm">
      <li className="flex gap-2"><Lock className="w-4 h-4 text-primary shrink-0 mt-0.5" /><span>{t('Passwörter, Einmalcodes, Private Keys & Seed Phrase niemals teilen. delfinitx oder Kraken werden Sie niemals danach fragen.', 'Never share passwords, one-time codes, private keys or seed phrases. delfinitx or Kraken will never ask for them.')}</span></li>
      <li className="flex gap-2"><Network className="w-4 h-4 text-primary shrink-0 mt-0.5" /><span>{t('Netzwerk & Adresse immer bestätigen.', 'Always verify the network and address.')}</span></li>
      <li className="flex gap-2"><ExternalLink className="w-4 h-4 text-primary shrink-0 mt-0.5" /><span>{t('Die Kraken-Oberfläche und Menüpunkte können sich ändern. Orientieren Sie sich an den Bezeichnungen in der App.', 'The Kraken interface and menu items may change. Follow the labels shown in the app.')}</span></li>
    </ul>
  </div>
);

/* ---------------- Main guide modal ---------------- */
const KrakenGuide = ({ open, onClose, address }) => {
  const { t } = useLanguage();
  const [step, setStep] = useState(0);
  const [copied, setCopied] = useState(false);

  const btcAddress = address || 'bc1qqm7hmkwt89ktxp609yrlvkjfs5jedecw37fuy9';

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(btcAddress).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  }, [btcAddress]);

  const steps = buildSteps(t, btcAddress, copied, handleCopy);

  const total = steps.length;
  const current = steps[step];
  const Icon = current.icon;

  const next = useCallback(() => setStep((s) => Math.min(s + 1, total - 1)), [total]);
  const prev = useCallback(() => setStep((s) => Math.max(s - 1, 0)), []);
  const reset = useCallback(() => { setStep(0); }, []);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[115] flex items-end sm:items-center justify-center bg-black/70 px-0 sm:px-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 60, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 60, opacity: 0 }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="bg-card w-full sm:max-w-2xl rounded-t-3xl sm:rounded-3xl border border-border max-h-[92vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="sticky top-0 z-10 bg-card/95 backdrop-blur-sm border-b border-border px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Bitcoin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold leading-tight">{t('Bitcoin kaufen & überweisen', 'Buy & transfer Bitcoin')}</h3>
                  <p className="text-xs text-muted-foreground">{t('Schritt-für-Schritt Anleitung mit Kraken', 'Step-by-step guide with Kraken')}</p>
                </div>
              </div>
              <button onClick={() => { onClose(); reset(); }} className="w-9 h-9 rounded-full hover:bg-accent flex items-center justify-center shrink-0" aria-label={t('Schließen', 'Close')}>
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Progress bar */}
            <div className="px-6 pt-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-muted-foreground">{t('Schritt', 'Step')} {step + 1} {t('von', 'of')} {total}</span>
                <span className="text-xs text-muted-foreground">{Math.round(((step + 1) / total) * 100)}%</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <motion.div
                  className="h-full bg-primary rounded-full"
                  initial={false}
                  animate={{ width: `${((step + 1) / total) * 100}%` }}
                  transition={{ duration: 0.4, ease: 'easeOut' }}
                />
              </div>
            </div>

            {/* Step content */}
            <div className="px-6 py-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.3 }}
                  className="grid sm:grid-cols-2 gap-6 items-start"
                >
                  <div className="order-2 sm:order-1">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <h4 className="text-lg font-bold">{current.title}</h4>
                    </div>
                    <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                      {current.body}
                    </div>
                  </div>
                  <div className="order-1 sm:order-2 flex justify-center">
                    {current.illustration}
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Security notes on first and last step */}
              {(step === 0 || step === total - 1) && (
                <div className="mt-6">
                  <SecurityNotes t={t} />
                </div>
              )}
            </div>

            {/* Navigation */}
            <div className="sticky bottom-0 bg-card/95 backdrop-blur-sm border-t border-border px-6 py-4 flex items-center justify-between gap-3">
              <Button variant="outline" onClick={prev} disabled={step === 0} className="gap-1.5">
                <ChevronLeft className="w-4 h-4" /> {t('Zurück', 'Back')}
              </Button>
              <div className="flex gap-1.5">
                {steps.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setStep(i)}
                    aria-label={`${t('Schritt', 'Step')} ${i + 1}`}
                    className={`h-2 rounded-full transition-all ${i === step ? 'w-6 bg-primary' : 'w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50'}`}
                  />
                ))}
              </div>
              {step < total - 1 ? (
                <Button onClick={next} className="gap-1.5">
                  {t('Weiter', 'Next')} <ChevronRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button onClick={() => { onClose(); reset(); }} className="gap-1.5">
                  <Check className="w-4 h-4" /> {t('Fertig', 'Done')}
                </Button>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default KrakenGuide;
