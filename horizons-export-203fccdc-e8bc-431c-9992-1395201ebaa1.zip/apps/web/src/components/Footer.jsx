import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail } from 'lucide-react';
import Logo from '@/components/Logo.jsx';
import CertificationBadges from '@/components/CertificationBadges.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] },
  }),
};

const FooterLink = ({ to, children, external = false }) => {
  const content = (
    <span className="relative inline-block group">
      <span className="transition-colors duration-200 group-hover:text-primary">
        {children}
      </span>
      <span className="absolute left-0 -bottom-0.5 h-px w-0 bg-primary transition-all duration-300 ease-out group-hover:w-full" />
    </span>
  );

  if (external) {
    return (
      <a href={to} className="text-sm text-muted-foreground">
        {content}
      </a>
    );
  }

  return (
    <Link to={to} className="text-sm text-muted-foreground">
      {content}
    </Link>
  );
};

const Footer = () => {
  const { t } = useLanguage();

  const quickLinks = [{
    name: t('Startseite', 'Home'),
    path: '/'
  }, {
    name: t('Leitfäden', 'Guides'),
    path: '/guides'
  }, {
    name: t('Über uns', 'About'),
    path: '/about'
  }, {
    name: t('Kontakt', 'Contact'),
    path: '/contact'
  }];
  const legalLinks = [{
    name: t('Datenschutzrichtlinie', 'Privacy Policy'),
    path: '/privacy-policy'
  }, {
    name: t('Nutzungsbedingungen', 'Terms of Service'),
    path: '#'
  }];

  return (
    <footer className="relative bg-card border-t border-border overflow-hidden">
      {/* Ambient glow accents, Kraken-style */}
      <div className="pointer-events-none absolute -top-24 left-1/4 w-72 h-72 rounded-full bg-primary/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 right-1/4 w-96 h-96 rounded-full bg-secondary/10 blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Top Section: Copyright, License, Certifications, Legal Links, and Company Capital */}
        <motion.div
          className="mb-4 pb-4 border-b border-border"
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeUp}
        >
          <p className="text-xs mb-1">
            © 2026 delfinitx. {t('Echtzeitdaten unterstützt', 'Powered by real-time data')}
          </p>
          <p className="text-xs text-muted-foreground mb-2">
            {t('Lizenz Nr.', 'License No.')} VL/23/07/003
          </p>
          <p className="text-xs text-muted-foreground mb-2">
            {t('SOC2 Type II und ISO27001 geprüft und zertifiziert — der Goldstandard für Sicherheitscompliance.', 'SOC2 Type II and ISO27001 audited and certified — the gold standard for security compliance.')}
          </p>
          <div className="flex flex-wrap gap-3 mb-2">
            {legalLinks.map(link => (
              <FooterLink key={link.name} to={link.path} external={!link.path.startsWith('/')}>
                {link.name}
              </FooterLink>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mb-2">
            {t('Gesellschaftskapital', 'Company Capital')}: US$54M
          </p>
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.2 }}
            variants={fadeUp}
            custom={1}
            className="transition-transform duration-300 [&_svg]:transition-transform [&_svg]:duration-300 hover:[&_svg]:scale-[1.03] scale-75 origin-left"
          >
            <CertificationBadges />
          </motion.div>
        </motion.div>

        {/* Main Content Section, Kraken-style column grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <motion.div
            className="md:col-span-2"
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.2 }}
            variants={fadeUp}
            custom={0}
          >
            <Logo className="mb-2" />
            <p className="text-xs leading-relaxed max-w-prose">
              {t('Echtzeit-Marktdaten für Kryptowährungen. Professionelle Handelswerkzeuge für moderne Anleger.', 'Real-time market data for cryptocurrencies. Professional trading tools for modern investors.')}
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.2 }}
            variants={fadeUp}
            custom={1}
          >
            <span className="text-xs font-semibold mb-2 block">{t('Schnelllinks', 'Quick Links')}</span>
            <ul className="space-y-1">
              {quickLinks.map(link => (
                <li key={link.path}>
                  <FooterLink to={link.path}>{link.name}</FooterLink>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.2 }}
            variants={fadeUp}
            custom={2}
          >
            <span className="text-xs font-semibold mb-2 block">{t('Support', 'Support')}</span>
            <div className="space-y-1">
              <a
                href="mailto:support@delfinitx.com"
                className="text-xs text-muted-foreground hover:text-primary transition-colors duration-200 flex items-center gap-2 group"
              >
                <Mail className="w-3 h-3 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:text-primary" />
                <span className="relative">
                  support@delfinitx.com
                  <span className="absolute left-0 -bottom-0.5 h-px w-0 bg-primary transition-all duration-300 ease-out group-hover:w-full" />
                </span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
