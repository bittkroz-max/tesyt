import React, { useEffect, useRef } from 'react';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const TradingViewWidget = () => {
  const containerRef = useRef(null);
  const { lang } = useLanguage();

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.innerHTML = '';

    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'tradingview-widget-container__widget';
    container.appendChild(widgetDiv);

    const script = document.createElement('script');
    script.src =
      'https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbols: [
        { proName: 'FOREXCOM:SPXUSD', title: 'S&P 500 Index' },
        { proName: 'FOREXCOM:NSXUSD', title: 'US 100 Cash CFD' },
        { proName: 'FX:EURUSD', title: 'EUR to USD' },
        { proName: 'BITSTAMP:BTCUSD', title: 'Bitcoin' },
        { proName: 'BITSTAMP:ETHUSD', title: 'Ethereum' },
        { proName: 'CMCMARKETS:GOLD', title: 'Gold' },
      ],
      showSymbolLogo: true,
      isTransparent: false,
      displayMode: 'adaptive',
      colorTheme: 'dark',
      locale: lang === 'en' ? 'en' : 'de',
    });

    container.appendChild(script);

    return () => {
      container.innerHTML = '';
    };
  }, [lang]);

  return (
    <div className="bg-[#0a0a0a] border-y border-border relative overflow-hidden">
      <div
        ref={containerRef}
        className="tradingview-widget-container"
        style={{ width: '100%' }}
      />
    </div>
  );
};

export default TradingViewWidget;
