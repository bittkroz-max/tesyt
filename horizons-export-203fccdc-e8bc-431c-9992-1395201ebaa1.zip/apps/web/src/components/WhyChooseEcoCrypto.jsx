import React from 'react';
import { motion } from 'framer-motion';
import { Leaf, TrendingUp, Shield, Wrench } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const WhyChooseEcoCrypto = () => {
  const { t } = useLanguage();
  const features = [{
    icon: Leaf,
    title: t('Nachhaltiger Fokus', 'Sustainable Focus'),
    description: t('Investieren Sie in Kryptowährungen mit ökologischer Verantwortung im Kern unserer Plattform.', 'Invest in cryptocurrencies with environmental responsibility at the core of our platform.'),
    color: 'primary'
  }, {
    icon: TrendingUp,
    title: t('Echtzeit-Analysen', 'Real-Time Analytics'),
    description: t('Zugang zu umfassenden Marktdaten und fortschrittlichen Analysetools für fundierte Entscheidungen.', 'Access comprehensive market data and advanced analytics tools for informed decision-making.'),
    color: 'secondary'
  }, {
    icon: Shield,
    title: t('Sicherheit zuerst', 'Security First'),
    description: t('Sicherheitsprotokolle auf Unternehmensebene schützen Ihre Vermögenswerte und persönlichen Daten.', 'Enterprise-grade security protocols protect your assets and personal information.'),
    color: 'primary'
  }, {
    icon: Wrench,
    title: t('Professionelle Werkzeuge', 'Professional Tools'),
    description: t('Leistungsstarke Handels- und Portfolioverwaltungs-Tools für professionelle Anleger.', 'Powerful trading and portfolio management tools designed for professional investors.'),
    color: 'secondary'
  }];

  return <section className="py-20 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.6
        }} viewport={{
          once: true
        }} className="text-3xl md:text-4xl font-bold mb-4" style={{
          letterSpacing: '-0.02em'
        }}>
            {t('Fortschrittliche professionelle Plattform', 'Advanced professional platform')}
          </motion.h2>
          <motion.p initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.6,
          delay: 0.1
        }} viewport={{
          once: true
        }} className="text-lg leading-relaxed max-w-2xl mx-auto">
            {t('Branchenführende Funktionen für nachhaltiges Krypto-Investieren', 'Industry-leading features designed for sustainable crypto investing')}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => {
          const Icon = feature.icon;
          return <motion.div key={feature.title} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.5,
            delay: index * 0.1
          }} viewport={{
            once: true
          }} whileHover={{
            scale: 1.02,
            y: -4
          }} className="bg-card rounded-2xl p-8 border border-border transition-all duration-300 hover:shadow-2xl hover:border-primary/30 cursor-pointer">
                <div className={`w-14 h-14 rounded-xl bg-${feature.color}/10 flex items-center justify-center mb-6`}>
                  <Icon className={`w-7 h-7 text-${feature.color}`} style={{
                color: `hsl(var(--${feature.color}))`
              }} />
                </div>
                <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                <p className="text-base leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>;
        })}
        </div>
      </div>
    </section>;
};
export default WhyChooseEcoCrypto;
