import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const StakingSection4 = () => {
  const { t } = useLanguage();
  return (
    <section className="py-20 bg-gradient-to-br from-background via-primary/5 to-secondary/5 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            style={{ letterSpacing: '-0.02em' }}
          >
            {t('Umfassende Staking-Plattform', 'Comprehensive Staking Platform')}
          </h2>
          <p className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto">
            {t('Zugang zu institutionellen Staking-Chancen über mehrere Blockchain-Netzwerke, gestützt durch strenge Sicherheitsaudits und transparente Belohnungsstrukturen.', 'Access institutional-grade staking opportunities across multiple blockchain networks, backed by rigorous security audits and transparent reward structures.')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <motion.img
              src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/17349e123b41f4eac1831fb8dcfe5a2f.png"
              alt={t('Kreisförmige Anordnung von Kryptowährungs-Symbolen', 'Circular arrangement of cryptocurrency icons')}
              className="w-full h-auto"
              animate={{
                rotate: [0, 5, 0, -5, 0],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img
              src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/24db11da23a83184abcaf84c908d8b31.png"
              alt={t('Raster von Kryptowährungs-Symbolen', 'Grid of cryptocurrency icons')}
              className="w-full h-auto rounded-2xl"
            />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-lg leading-relaxed max-w-3xl mx-auto mb-8">
            {t('Von Bitcoin und Ethereum bis hin zu aufstrebenden DeFi-Protokollen unterstützt unsere Plattform eine breite Palette von Kryptowährungen für Staking. Jedes Asset wird sorgfältig auf Sicherheit, Nachhaltigkeit und langfristige Lebensfähigkeit geprüft.', 'From Bitcoin and Ethereum to emerging DeFi protocols, our platform supports a wide range of cryptocurrencies for staking. Each asset is carefully vetted for security, sustainability, and long-term viability.')}
          </p>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="group gap-2 rounded-full border-primary/30 hover:border-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 active:scale-[0.98]"
          >
            <Link to="/guides">
              {t('Mehr erfahren', 'Learn More')}
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default StakingSection4;
