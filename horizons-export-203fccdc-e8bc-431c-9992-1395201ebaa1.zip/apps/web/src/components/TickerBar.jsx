import React, { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

// The requested markets for the homepage ticker.
// Baseline values are used immediately so the bar always renders and scrolls,
// then live crypto prices (BTC/ETH) are layered on top when available.
const INITIAL_MARKETS = [
  { key: 'cfd', label: 'CFD', price: 1.0842, change: 0.42, prefix: '', decimals: 4 },
  { key: 'eurusd', label: 'EUR/USD', price: 1.0876, change: -0.18, prefix: '', decimals: 4 },
  { key: 'btc', label: 'Bitcoin', price: 67450.0, change: 2.34, prefix: '$', decimals: 2 },
  { key: 'eth', label: 'Ethereum', price: 3520.0, change: 1.76, prefix: '$', decimals: 2 },
  { key: 'gold', label: 'Gold', price: 2338.5, change: 0.63, prefix: '$', decimals: 2 },
  { key: 'sp500', label: 'S&P 500', price: 5487.0, change: 0.91, prefix: '', decimals: 2 },
];

const formatPrice = (value, decimals) =>
  value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });

const TickerBar = () => {
  const [markets, setMarkets] = useState(INITIAL_MARKETS);
  const [flash, setFlash] = useState({});
  const marketsRef = useRef(INITIAL_MARKETS);

  // Try to pull live BTC/ETH prices from CoinGecko; ignore failures gracefully.
  useEffect(() => {
    let cancelled = false;

    const fetchLive = async () => {
      try {
        const res = await fetch(
          'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true'
        );
        if (!res.ok) return;
        const json = await res.json();
        if (cancelled || !json) return;

        setMarkets((prev) =>
          prev.map((m) => {
            if (m.key === 'btc' && json.bitcoin) {
              return { ...m, price: json.bitcoin.usd, change: json.bitcoin.usd_24h_change ?? m.change };
            }
            if (m.key === 'eth' && json.ethereum) {
              return { ...m, price: json.ethereum.usd, change: json.ethereum.usd_24h_change ?? m.change };
            }
            return m;
          })
        );
      } catch {
        // Network blocked — keep baseline values; the ticker still renders and scrolls.
      }
    };

    fetchLive();
    const interval = setInterval(fetchLive, 60000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  // Simulate small live fluctuations so the values feel real-time even when
  // external feeds are unavailable in this environment.
  useEffect(() => {
    const interval = setInterval(() => {
      const nextFlash = {};
      setMarkets((prev) => {
        const updated = prev.map((m) => {
          const drift = (Math.random() - 0.5) * 0.0015; // +/- 0.15%
          const newPrice = Math.max(m.price * (1 + drift), 0.0001);
          const newChange = Math.max(Math.min(m.change + (Math.random() - 0.5) * 0.08, 15), -15);
          if (newPrice > m.price) nextFlash[m.key] = 'up';
          else if (newPrice < m.price) nextFlash[m.key] = 'down';
          return { ...m, price: newPrice, change: newChange };
        });
        marketsRef.current = updated;
        return updated;
      });
      setFlash(nextFlash);
      setTimeout(() => setFlash({}), 600);
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  const tickerData = [...markets, ...markets];

  return (
    <div className="bg-card border-y border-border overflow-hidden py-3">
      <div className="ticker-wrapper">
        <div className="ticker-content">
          {tickerData.map((market, index) => {
            const isPositive = market.change >= 0;
            const hasChange = flash[market.key];

            return (
              <div
                key={`${market.key}-${index}`}
                className={`ticker-item flex items-center gap-2 px-6 transition-all duration-200 ${
                  hasChange === 'up' ? 'price-up' : hasChange === 'down' ? 'price-down' : ''
                }`}
              >
                <span className="text-sm font-bold">{market.label}</span>
                <span className="price-text text-sm font-semibold">
                  {market.prefix}
                  {formatPrice(market.price, market.decimals)}
                </span>
                <span
                  className={`flex items-center gap-1 text-xs font-medium ${
                    isPositive ? 'text-secondary' : 'text-destructive'
                  }`}
                >
                  {isPositive ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {isPositive ? '+' : ''}
                  {market.change.toFixed(2)}%
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default TickerBar;
