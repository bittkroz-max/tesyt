import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Search, LogOut, Languages } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import Logo from '@/components/Logo.jsx';
import { useAuth } from '@/hooks/useAuth.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthed, isAdmin, logout } = useAuth();
  const { lang, setLang, t } = useLanguage();

  const navItems = [
    { name: t('Startseite', 'Home'), path: '/' },
    { name: t('Leitfäden', 'Guides'), path: '/guides' },
    ...(isAuthed ? [{ name: t('Wallet', 'Wallet'), path: '/wallet' }] : []),
    ...(isAdmin ? [{ name: 'delfinitx', path: '/admin' }] : []),
    { name: t('Über uns', 'About'), path: '/about' },
    { name: t('Kontakt', 'Contact'), path: '/contact' },
  ];

  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    logout();
    setMobileMenuOpen(false);
    navigate('/');
  };

  const LangToggle = ({ className = '' }) => (
    <div className={`flex items-center rounded-lg border border-border p-0.5 ${className}`}>
      <button
        onClick={() => setLang('de')}
        className={`px-2 py-1 rounded-md text-xs font-semibold transition-colors ${lang === 'de' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
        aria-label="Deutsch"
      >
        DE
      </button>
      <button
        onClick={() => setLang('en')}
        className={`px-2 py-1 rounded-md text-xs font-semibold transition-colors ${lang === 'en' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
        aria-label="English"
      >
        EN
      </button>
    </div>
  );

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="group">
            <Logo />
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  isActive(item.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <LangToggle />
            <Button
              variant="ghost"
              size="icon"
              className="transition-all duration-200"
              aria-label={t('Suche', 'Search')}
            >
              <Search className="h-5 w-5" />
            </Button>
            {isAuthed ? (
              <Button
                onClick={handleLogout}
                size="sm"
                variant="outline"
                className="transition-all duration-200 active:scale-[0.98] gap-1.5"
              >
                <LogOut className="h-4 w-4" />
                {t('Abmelden', 'Log out')}
              </Button>
            ) : (
              <>
                <Button asChild size="sm" variant="outline" className="transition-all duration-200 active:scale-[0.98]">
                  <Link to="/login">{t('Anmelden', 'Log in')}</Link>
                </Button>
                <Button asChild size="sm" className="transition-all duration-200 active:scale-[0.98] bg-primary text-primary-foreground hover:bg-primary/90">
                  <Link to="/signup">{t('Registrieren', 'Sign up')}</Link>
                </Button>
              </>
            )}
          </div>

          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <nav className="flex flex-col gap-4 mt-8">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                      isActive(item.path)
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
                <div className="pt-2">
                  <LangToggle className="w-full justify-center" />
                </div>
                <div className="pt-4 border-t border-border flex flex-col gap-3">
                  {isAuthed ? (
                    <Button onClick={handleLogout} variant="outline" className="w-full gap-1.5">
                      <LogOut className="h-4 w-4" />{t('Abmelden', 'Log out')}
                    </Button>
                  ) : (
                    <>
                      <Button asChild variant="outline" className="w-full">
                        <Link to="/login" onClick={() => setMobileMenuOpen(false)}>{t('Anmelden', 'Log in')}</Link>
                      </Button>
                      <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                        <Link to="/signup" onClick={() => setMobileMenuOpen(false)}>{t('Registrieren', 'Sign up')}</Link>
                      </Button>
                    </>
                  )}
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
