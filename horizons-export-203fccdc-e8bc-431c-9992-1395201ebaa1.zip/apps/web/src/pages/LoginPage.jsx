import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bitcoin, Loader2 } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const inputCls =
  'w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring';

const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const rec = await login(form.email, form.password);
      if (rec?.role === 'admin') navigate('/admin');
      else navigate('/wallet');
    } catch (err) {
      setError(t('Ungültige E-Mail oder Passwort.', 'Invalid email or password.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>{t('Anmelden - delfinitx', 'Log In - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-card border border-border rounded-2xl p-8">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Bitcoin className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-2xl font-bold">{t('Willkommen zurück', 'Welcome back')}</h1>
              <p className="text-sm text-muted-foreground mt-1">{t('In Ihr Konto einloggen', 'Log in to your account')}</p>
            </div>
            <form onSubmit={submit} className="space-y-4">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium">{t('E-Mail', 'Email')}</label>
                <input type="email" className={inputCls} value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="you@example.com" />
              </div>
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">{t('Passwort', 'Password')}</label>
                  <Link to="/forgot-password" className="text-xs text-primary font-medium hover:underline">
                    {t('Passwort vergessen?', 'Forgot password?')}
                  </Link>
                </div>
                <input type="password" className={inputCls} value={form.password}
                  onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder={t('Ihr Passwort', 'Your password')} />
              </div>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" disabled={loading} className="w-full h-12">
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Anmelden', 'Log In')}
              </Button>
              <p className="text-sm text-muted-foreground text-center">
                {t('Kein Konto?', 'No account?')} <Link to="/signup" className="text-primary font-medium">{t('Registrieren', 'Sign up')}</Link>
              </p>
            </form>
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default LoginPage;
