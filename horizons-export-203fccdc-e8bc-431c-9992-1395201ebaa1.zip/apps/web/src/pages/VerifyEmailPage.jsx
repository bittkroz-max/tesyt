import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bitcoin, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import pb from '@/lib/pocketbaseClient';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const verificationAttempts = new Map();

function decodeJwtPayload(token) {
  try {
    const part = token.split('.')[1];
    const json = atob(part.replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(json);
  } catch (_) {
    return null;
  }
}

function isTokenExpired(token) {
  const payload = decodeJwtPayload(token);
  if (!payload || !payload.exp) return false;
  return Date.now() >= payload.exp * 1000;
}

async function runVerification(token) {
  if (!verificationAttempts.has(token)) {
    const promise = pb
      .collection('users')
      .confirmVerification(token)
      .then(() => true);
    verificationAttempts.set(token, promise);
  }
  return verificationAttempts.get(token);
}

const VerifyEmailPage = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { token: tokenParam } = useParams();
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('verifying');
  const [errorMsg, setErrorMsg] = useState('');

  const token = tokenParam || searchParams.get('token') || '';

  useEffect(() => {
    let active = true;

    if (!token || token.split('.').length !== 3) {
      setStatus('error');
      setErrorMsg(t('Dieser Verifizierungslink fehlt oder ist ungültig.', 'This verification link is missing or invalid.'));
      return () => { active = false; };
    }

    if (isTokenExpired(token)) {
      setStatus('error');
      setErrorMsg(t('Dieser Verifizierungslink ist abgelaufen. Bitte fordern Sie einen neuen an.', 'This verification link has expired. Please request a new one.'));
      return () => { active = false; };
    }

    runVerification(token)
      .then(() => {
        if (!active) return;
        setStatus('success');
        setTimeout(() => { if (active) navigate('/login'); }, 3000);
      })
      .catch((err) => {
        if (!active) return;
        const already = err && err.response && err.response.data
          && JSON.stringify(err.response.data).includes('already');
        if (already) {
          setStatus('success');
          setTimeout(() => { if (active) navigate('/login'); }, 3000);
          return;
        }
        verificationAttempts.delete(token);
        setStatus('error');
        setErrorMsg(t('Dieser Verifizierungslink ist abgelaufen oder wurde bereits verwendet.', 'This verification link has expired or was already used.'));
      });

    return () => { active = false; };
  }, [token, navigate, t]);

  return (
    <>
      <Helmet><title>{t('E-Mail verifizieren - delfinitx', 'Verify Email - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-card border border-border rounded-2xl p-8 text-center">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Bitcoin className="w-6 h-6 text-primary" />
              </div>
              <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">delfinitx</p>
            </div>

            {status === 'verifying' && (
              <>
                <Loader2 className="w-12 h-12 text-primary mx-auto mb-4 animate-spin" />
                <h1 className="text-xl font-bold mb-2">{t('E-Mail wird verifiziert …', 'Verifying your email…')}</h1>
                <p className="text-sm text-muted-foreground">{t('Bitte warten Sie einen Moment, während wir Ihre Adresse bestätigen.', 'Please wait a moment while we confirm your address.')}</p>
              </>
            )}

            {status === 'success' && (
              <>
                <CheckCircle2 className="w-14 h-14 text-secondary mx-auto mb-4" />
                <h1 className="text-xl font-bold mb-2">{t('E-Mail verifiziert!', 'Email verified!')}</h1>
                <p className="text-sm text-muted-foreground mb-6">
                  {t('Warten Sie nun auf die Freigabe durch delfinitx. Sie können sich einloggen, sobald Ihr Konto geprüft wurde.', 'Now wait for delfinitx approval. You\'ll be able to log in once your account is reviewed.')}
                </p>
                <p className="text-xs text-muted-foreground">{t('Sie werden zum Login weitergeleitet …', 'Redirecting you to login…')}</p>
              </>
            )}

            {status === 'error' && (
              <>
                <XCircle className="w-14 h-14 text-destructive mx-auto mb-4" />
                <h1 className="text-xl font-bold mb-2">{t('Verifizierung fehlgeschlagen', 'Verification failed')}</h1>
                <p className="text-sm text-muted-foreground mb-6">{errorMsg}</p>
                <Button className="w-full" onClick={() => navigate('/login')}>{t('Zum Login', 'Go to login')}</Button>
              </>
            )}
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default VerifyEmailPage;
