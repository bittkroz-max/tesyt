import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bitcoin, Loader2, CheckCircle2 } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import pb from '@/lib/pocketbaseClient';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const inputCls =
  'w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring';

const ResetPasswordPage = () => {
  const { token } = useParams();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [form, setForm] = useState({ password: '', confirm: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');

    if (!form.password || form.password.length < 8) {
      setError(t('Das Passwort muss mindestens 8 Zeichen lang sein.', 'Password must be at least 8 characters long.'));
      return;
    }
    if (form.password !== form.confirm) {
      setError(t('Die beiden Passwörter stimmen nicht überein.', 'The two passwords do not match.'));
      return;
    }

    setLoading(true);
    try {
      await pb.collection('users').confirmPasswordReset(token, form.password, form.confirm);
      setSuccess(true);
      setTimeout(() => navigate('/login'), 2500);
    } catch (err) {
      setError(t('Dieser Link ist ungültig oder abgelaufen. Bitte fordern Sie einen neuen Link an.', 'This link is invalid or has expired. Please request a new link.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>{t('Passwort zurücksetzen - delfinitx', 'Reset Password - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-card border border-border rounded-2xl p-8">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Bitcoin className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-2xl font-bold">{t('Neues Passwort erstellen', 'Create a new password')}</h1>
              <p className="text-sm text-muted-foreground mt-1 text-center">
                {t('Wählen Sie ein neues Passwort für Ihr Konto.', 'Choose a new password for your account.')}
              </p>
            </div>

            {success ? (
              <div className="flex flex-col items-center gap-3 py-4 text-center">
                <CheckCircle2 className="w-10 h-10 text-secondary" />
                <p className="text-sm">{t('Ihr Passwort wurde erfolgreich aktualisiert. Sie werden zum Login weitergeleitet …', 'Your password has been updated successfully. Redirecting you to login...')}</p>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">{t('Neues Passwort', 'New password')}</label>
                  <input
                    type="password"
                    className={inputCls}
                    value={form.password}
                    onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                    placeholder={t('Mindestens 8 Zeichen', 'At least 8 characters')}
                    required
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">{t('Passwort bestätigen', 'Confirm password')}</label>
                  <input
                    type="password"
                    className={inputCls}
                    value={form.confirm}
                    onChange={(e) => setForm((f) => ({ ...f, confirm: e.target.value }))}
                    placeholder={t('Neues Passwort wiederholen', 'Repeat your new password')}
                    required
                  />
                </div>
                {error && <p className="text-sm text-destructive">{error}</p>}
                <Button type="submit" disabled={loading} className="w-full h-12">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Passwort zurücksetzen', 'Reset password')}
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  <Link to="/login" className="text-primary font-medium">{t('Zurück zum Login', 'Back to login')}</Link>
                </p>
              </form>
            )}
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default ResetPasswordPage;
