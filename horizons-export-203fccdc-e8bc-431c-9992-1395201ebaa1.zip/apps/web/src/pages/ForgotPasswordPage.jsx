import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bitcoin, Loader2, CheckCircle2 } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import pb from '@/lib/pocketbaseClient';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const inputCls =
  'w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring';

const ForgotPasswordPage = () => {
  const { t } = useLanguage();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!email.trim()) return;
    setError('');
    setLoading(true);
    try {
      await pb.collection('users').requestPasswordReset(email.trim());
    } catch (err) {
      // Intentionally swallow to avoid leaking whether an email exists.
    } finally {
      setLoading(false);
      setSubmitted(true);
    }
  };

  return (
    <>
      <Helmet><title>{t('Passwort vergessen - delfinitx', 'Forgot Password - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-card border border-border rounded-2xl p-8">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Bitcoin className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-2xl font-bold">{t('Passwort vergessen?', 'Forgot your password?')}</h1>
              <p className="text-sm text-muted-foreground mt-1 text-center">
                {t('Geben Sie Ihre E-Mail ein und wir senden Ihnen einen Link zum Zurücksetzen Ihres Passworts.', 'Enter your email and we\'ll send you a link to reset your password.')}
              </p>
            </div>

            {submitted ? (
              <div className="flex flex-col items-center gap-3 py-4 text-center">
                <CheckCircle2 className="w-10 h-10 text-secondary" />
                <p className="text-sm">
                  {t('Wenn ein Konto mit dieser E-Mail existiert, erhalten Sie in Kürze einen Link zum Zurücksetzen des Passworts.', 'If an account exists with this email, you\'ll receive a password reset link shortly.')}
                </p>
                <Link to="/login" className="text-primary font-medium text-sm mt-2">
                  {t('Zurück zum Login', 'Back to login')}
                </Link>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">{t('E-Mail', 'Email')}</label>
                  <input
                    type="email"
                    className={inputCls}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    required
                  />
                </div>
                {error && <p className="text-sm text-destructive">{error}</p>}
                <Button type="submit" disabled={loading} className="w-full h-12">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Reset-Link senden', 'Send reset link')}
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  <Link to="/login" className="text-primary font-medium">{t('Zurück zum Login', 'Back to login')}</Link>
                </p>
              </form>
            )}
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default ForgotPasswordPage;
