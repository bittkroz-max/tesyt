import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bitcoin, Loader2, MailCheck } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth.jsx';
import { sendEmailNotification } from '@/lib/emailNotifications';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const inputCls =
  'w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring';

const SignUpPage = () => {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.name || !form.email || form.password.length < 8) {
      setError(t('Bitte alle Felder ausfüllen. Das Passwort muss mindestens 8 Zeichen lang sein.', 'Fill all fields. Password must be at least 8 characters.'));
      return;
    }
    setLoading(true);
    try {
      await signup(form);
      sendEmailNotification(
        'New Client Registered',
        `A new client registered: ${form.name} (${form.email}). Awaiting email verification and delfinitx approval.`,
        { client_email: form.email, client_name: form.name },
      );
      setDone(true);
    } catch (err) {
      setError(err?.response?.data?.email?.message || err?.message || t('Registrierung fehlgeschlagen.', 'Sign up failed.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>{t('Registrieren - delfinitx', 'Sign Up - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-card border border-border rounded-2xl p-8">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Bitcoin className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-2xl font-bold">{t('Konto erstellen', 'Create your account')}</h1>
              <p className="text-sm text-muted-foreground mt-1">{t('delfinitx beitreten', 'Join delfinitx')}</p>
            </div>

            {done ? (
              <div className="text-center py-4">
                <MailCheck className="w-12 h-12 text-secondary mx-auto mb-4" />
                <h2 className="text-lg font-bold mb-2">{t('E-Mail prüfen', 'Check your email')}</h2>
                <p className="text-sm text-muted-foreground mb-6">
                  {t('Wir haben einen Verifizierungslink an ', 'We sent a verification link to ')}<span className="font-medium text-foreground">{form.email}</span>{t(' gesendet. Verifizieren Sie Ihre E-Mail, danach wird Ihr Konto von delfinitx geprüft, bevor Sie auf die Wallet zugreifen können.', '. Verify your email, then your account will be reviewed by delfinitx before you can access the wallet.')}
                </p>
                <Button className="w-full" onClick={() => navigate('/login')}>{t('Zum Login', 'Go to login')}</Button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">{t('Name', 'Name')}</label>
                  <input className={inputCls} value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder={t('Ihr Name', 'Your name')} />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">{t('E-Mail', 'Email')}</label>
                  <input type="email" className={inputCls} value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="you@example.com" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-medium">{t('Passwort', 'Password')}</label>
                  <input type="password" className={inputCls} value={form.password}
                    onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder={t('Mindestens 8 Zeichen', 'At least 8 characters')} />
                </div>
                {error && <p className="text-sm text-destructive">{error}</p>}
                <Button type="submit" disabled={loading} className="w-full h-12">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Registrieren', 'Sign Up')}
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  {t('Schon ein Konto?', 'Already have an account?')} <Link to="/login" className="text-primary font-medium">{t('Anmelden', 'Log in')}</Link>
                </p>
              </form>
            )}
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default SignUpPage;
