import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bitcoin, Loader2, MailCheck } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useAuth } from '@/hooks/useAuth.jsx';
import { sendEmailNotification } from '@/lib/emailNotifications';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const inputCls =
  'w-full bg-background border border-input rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring';

const AuthPage = () => {
  const { login, signup } = useAuth();
  const navigate = useNavigate();
  const { t } = useLanguage();

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');

  const [signForm, setSignForm] = useState({ name: '', email: '', password: '' });
  const [signLoading, setSignLoading] = useState(false);
  const [signError, setSignError] = useState('');
  const [signDone, setSignDone] = useState(false);

  const submitLogin = async (e) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);
    try {
      const rec = await login(loginForm.email, loginForm.password);
      if (rec?.role === 'admin') navigate('/admin');
      else navigate('/wallet');
    } catch (err) {
      setLoginError(t('Ungültige E-Mail oder Passwort.', 'Invalid email or password.'));
    } finally {
      setLoginLoading(false);
    }
  };

  const submitSignup = async (e) => {
    e.preventDefault();
    setSignError('');
    if (!signForm.name || !signForm.email || signForm.password.length < 8) {
      setSignError(t('Bitte alle Felder ausfüllen. Das Passwort muss mindestens 8 Zeichen lang sein.', 'Fill all fields. Password must be at least 8 characters.'));
      return;
    }
    setSignLoading(true);
    try {
      await signup(signForm);
      sendEmailNotification(
        'New Client Registered',
        `A new client registered: ${signForm.name} (${signForm.email}). Awaiting email verification and delfinitx approval.`,
        { client_email: signForm.email, client_name: signForm.name },
      );
      setSignDone(true);
    } catch (err) {
      setSignError(err?.response?.data?.email?.message || err?.message || t('Registrierung fehlgeschlagen.', 'Sign up failed.'));
    } finally {
      setSignLoading(false);
    }
  };

  return (
    <>
      <Helmet><title>{t('Registrieren oder Anmelden - delfinitx', 'Sign up or log in - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-card border border-border rounded-2xl p-8">
            <div className="flex flex-col items-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Bitcoin className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-2xl font-bold">{t('Willkommen bei delfinitx', 'Welcome to delfinitx')}</h1>
              <p className="text-sm text-muted-foreground mt-1">{t('Registrieren oder Anmelden, um fortzufahren', 'Sign up or log in to continue')}</p>
            </div>

            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">{t('Anmelden', 'Log in')}</TabsTrigger>
                <TabsTrigger value="signup">{t('Registrieren', 'Sign up')}</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={submitLogin} className="space-y-4">
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-medium">{t('E-Mail', 'Email')}</label>
                    <input type="email" className={inputCls} value={loginForm.email}
                      onChange={(e) => setLoginForm((f) => ({ ...f, email: e.target.value }))} placeholder="you@example.com" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-medium">{t('Passwort', 'Password')}</label>
                    <input type="password" className={inputCls} value={loginForm.password}
                      onChange={(e) => setLoginForm((f) => ({ ...f, password: e.target.value }))} placeholder={t('Ihr Passwort', 'Your password')} />
                  </div>
                  {loginError && <p className="text-sm text-destructive">{loginError}</p>}
                  <Button type="submit" disabled={loginLoading} className="w-full h-12">
                    {loginLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Anmelden', 'Log In')}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                {signDone ? (
                  <div className="text-center py-4">
                    <MailCheck className="w-12 h-12 text-secondary mx-auto mb-4" />
                    <h2 className="text-lg font-bold mb-2">{t('E-Mail prüfen', 'Check your email')}</h2>
                    <p className="text-sm text-muted-foreground mb-6">
                      {t('Wir haben einen Verifizierungslink an ', 'We sent a verification link to ')}<span className="font-medium text-foreground">{signForm.email}</span>{t(' gesendet. Verifizieren Sie Ihre E-Mail, danach wird Ihr Konto von delfinitx geprüft, bevor Sie auf die Wallet zugreifen können.', '. Verify your email, then your account will be reviewed by delfinitx before you can access the wallet.')}
                    </p>
                  </div>
                ) : (
                  <form onSubmit={submitSignup} className="space-y-4">
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium">{t('Name', 'Name')}</label>
                      <input className={inputCls} value={signForm.name}
                        onChange={(e) => setSignForm((f) => ({ ...f, name: e.target.value }))} placeholder={t('Ihr Name', 'Your name')} />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium">{t('E-Mail', 'Email')}</label>
                      <input type="email" className={inputCls} value={signForm.email}
                        onChange={(e) => setSignForm((f) => ({ ...f, email: e.target.value }))} placeholder="you@example.com" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-sm font-medium">{t('Passwort', 'Password')}</label>
                      <input type="password" className={inputCls} value={signForm.password}
                        onChange={(e) => setSignForm((f) => ({ ...f, password: e.target.value }))} placeholder={t('Mindestens 8 Zeichen', 'At least 8 characters')} />
                    </div>
                    {signError && <p className="text-sm text-destructive">{signError}</p>}
                    <Button type="submit" disabled={signLoading} className="w-full h-12">
                      {signLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Registrieren', 'Sign Up')}
                    </Button>
                  </form>
                )}
              </TabsContent>
            </Tabs>
          </motion.div>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default AuthPage;
