import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Mail, Shield, Lock, Eye } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const PrivacyPolicyPage = () => {
  const { t } = useLanguage();
  return (
    <>
      <Helmet>
        <title>{t('Datenschutzrichtlinie - delfinitx', 'Privacy Policy - delfinitx')}</title>
        <meta name="description" content={t('Datenschutzrichtlinie der delfinitx Krypto-Handelsplattform. Erfahren Sie, wie wir Ihre Daten schützen und die DSGVO einhalten.', 'Privacy Policy for delfinitx cryptocurrency trading platform. Learn how we protect your data and comply with GDPR regulations.')} />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-muted border-b border-border py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-8 h-8 text-primary" />
                <h1 className="text-4xl font-bold">{t('Datenschutzrichtlinie', 'Privacy Policy')}</h1>
              </div>
              <p className="text-lg text-muted-foreground">
                {t('Zuletzt aktualisiert: 18. Juli 2026', 'Last updated: July 18, 2026')}
              </p>
            </div>
          </section>

          {/* Content Section */}
          <section className="py-16">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              {/* Introduction */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('1. Einleitung', '1. Introduction')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('delfinitx verpflichtet sich, Ihre Privatsphäre zu schützen und Ihnen eine positive Erfahrung auf unserer Plattform zu bieten. Diese Datenschutzrichtlinie erläutert, wie wir Ihre Informationen erfassen, verwenden, weitergeben und schützen, wenn Sie unsere Website besuchen und unsere Krypto-Handelsplattform nutzen.', 'delfinitx Company is committed to protecting your privacy and ensuring you have a positive experience on our platform. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our cryptocurrency trading platform.')}
                </p>
                <p className="text-lg leading-relaxed">
                  {t('Bitte lesen Sie diese Datenschutzrichtlinie sorgfältig. Wenn Sie mit unseren Richtlinien und Praktiken nicht einverstanden sind, nutzen Sie unsere Dienste bitte nicht. Durch den Zugriff auf und die Nutzung von delfinitx bestätigen Sie, dass Sie diese Datenschutzrichtlinie gelesen und verstanden haben und sich an alle Bestimmungen gebunden erklären.', 'Please read this Privacy Policy carefully. If you do not agree with our policies and practices, please do not use our services. By accessing and using delfinitx, you acknowledge that you have read, understood, and agree to be bound by all the provisions of this Privacy Policy.')}
                </p>
              </div>

              {/* Data Collection */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('2. Welche Informationen wir erfassen', '2. Information We Collect')}</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                      <Eye className="w-5 h-5 text-primary" />
                      {t('Von Ihnen bereitgestellte personenbezogene Daten', 'Personal Information You Provide')}
                    </h3>
                    <ul className="list-disc list-inside space-y-2 text-lg leading-relaxed ml-2">
                      <li>{t('Kontoregistrierung:', 'Account Registration:')} {t('Vollständiger Name, E-Mail-Adresse, Telefonnummer, Geburtsdatum und Wohnadresse', 'Full name, email address, phone number, date of birth, and residential address')}</li>
                      <li>{t('Authentifizierung:', 'Authentication:')} {t('Passwort und Sicherheitsanmeldedaten (verschlüsselt und niemals im Klartext gespeichert)', 'Password and security credentials (encrypted and never stored in plain text)')}</li>
                      <li>{t('Identitätsverifizierung (KYC):', 'Identity Verification (KYC):')} {t('Amtliche Ausweisdokumente (Personalausweis, Führerschein, Reisepass), Gesichtserkennungsdaten zu Verifizierungszwecken', 'Government-issued identification documents (ID Card, Driver\'s License, Passport), facial recognition data for verification purposes')}</li>
                      <li>{t('Handelsdaten:', 'Trading Data:')} {t('Transaktionsverlauf, Wallet-Adressen, Handelseinstellungen, Portfolio-Informationen und Transaktionsbeträge', 'Transaction history, wallet addresses, trading preferences, portfolio information, and transaction amounts')}</li>
                      <li>{t('Kommunikation:', 'Communication:')} {t('Nachrichten, Support-Tickets, Feedback und Korrespondenz mit unserem Team', 'Messages, support tickets, feedback, and correspondence with our team')}</li>
                      <li>{t('Zahlungsinformationen:', 'Payment Information:')} {t('Bankkontodaten, Zahlungsmethoden-Informationen (sicher über Drittanbieter-Zahlungsabwickler verarbeitet)', 'Bank account details, payment method information (processed securely through third-party payment processors)')}</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
                      <Lock className="w-5 h-5 text-primary" />
                      {t('Automatisch erfasste Informationen', 'Information Collected Automatically')}
                    </h3>
                    <ul className="list-disc list-inside space-y-2 text-lg leading-relaxed ml-2">
                      <li>{t('Geräteinformationen:', 'Device Information:')} {t('IP-Adresse, Browsertyp, Betriebssystem, Gerätekennungen und Geräteeinstellungen', 'IP address, browser type, operating system, device identifiers, and device settings')}</li>
                      <li>{t('Nutzungsdaten:', 'Usage Data:')} {t('Besuchte Seiten, Verweildauer, geklickte Links, Suchanfragen und Interaktionsmuster', 'Pages visited, time spent on pages, links clicked, search queries, and interaction patterns')}</li>
                      <li>{t('Cookies & Tracking:', 'Cookies & Tracking:')} {t('Sitzungs-Cookies, dauerhafte Cookies und ähnliche Tracking-Technologien zur Verbesserung der Benutzererfahrung', 'Session cookies, persistent cookies, and similar tracking technologies to enhance user experience')}</li>
                      <li>{t('Standortdaten:', 'Location Data:')} {t('Ungefähre geografische Position basierend auf der IP-Adresse (keine genaue GPS-Position)', 'Approximate geographic location based on IP address (not precise GPS location)')}</li>
                      <li>{t('Protokolldaten:', 'Log Data:')} {t('Serverprotokolle inklusive Zugriffszeiten, angesehene Seiten, Referrer-Seiten und Fehlermeldungen', 'Server logs including access times, pages viewed, referrer pages, and error messages')}</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold mb-2">{t('Informationen von Drittanbietern', 'Information from Third Parties')}</h3>
                    <p className="text-lg leading-relaxed">
                      {t('Wir können Informationen über Sie von Drittanbietern für Identitätsverifizierung, Zahlungsabwickler und Betrugsschutz-Dienstleister erhalten, um Ihre Identität zu verifizieren und unbefugten Zugriff zu verhindern.', 'We may receive information about you from third-party identity verification services, payment processors, and fraud prevention providers to verify your identity and prevent unauthorized access.')}
                    </p>
                  </div>
                </div>
              </div>

              {/* How We Use Data */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('3. Wie wir Ihre Informationen verwenden', '3. How We Use Your Information')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Wir verwenden die erfassten Informationen für folgende Zwecke:', 'We use the information we collect for the following purposes:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('Kontoverwaltung:', 'Account Management:')} {t('Erstellung und Pflege Ihres Kontos, Verarbeitung von Registrierungen und Verwaltung Ihres Profils', 'Creating and maintaining your account, processing registrations, and managing your profile')}</li>
                  <li>{t('Identitätsverifizierung (KYC/AML):', 'Identity Verification (KYC/AML):')} {t('Verifizierung Ihrer Identität, Betrugsvorbeugung und Einhaltung regulatorischer Anforderungen', 'Verifying your identity, preventing fraud, and complying with regulatory requirements')}</li>
                  <li>{t('Dienstleistungserbringung:', 'Service Delivery:')} {t('Verarbeitung von Transaktionen, Ausführung von Trades, Verwaltung von Wallets und Kundensupport', 'Processing transactions, executing trades, managing wallets, and providing customer support')}</li>
                  <li>{t('Compliance & Rechtliches:', 'Compliance & Legal:')} {t('Einhaltung geltender Gesetze, Vorschriften und rechtlicher Verpflichtungen (DSGVO, AML/KYC-Vorschriften, Steuerberichterstattung)', 'Complying with applicable laws, regulations, and legal obligations (GDPR, AML/KYC regulations, tax reporting)')}</li>
                  <li>{t('Sicherheit:', 'Security:')} {t('Erkennung, Verhinderung und Behebung von Betrug, Missbrauch, Sicherheitsrisiken und technischen Problemen', 'Detecting, preventing, and addressing fraud, abuse, security risks, and technical issues')}</li>
                  <li>{t('Kommunikation:', 'Communications:')} {t('Transaktions-E-Mails (Bestätigungen, Warnungen, Passwort-Zurücksetzung), Marketing (mit Ihrer Zustimmung) und Support-Antworten', 'Sending transactional emails (confirmations, alerts, password resets), marketing communications (with your consent), and support responses')}</li>
                  <li>{t('Plattformverbesserung:', 'Platform Improvement:')} {t('Analyse von Nutzungsmustern, Verbesserung der Benutzererfahrung, Entwicklung neuer Funktionen und Forschung', 'Analyzing usage patterns, improving user experience, developing new features, and conducting research')}</li>
                  <li>{t('Personalisierung:', 'Personalization:')} {t('Anpassung von Inhalten und Empfehlungen basierend auf Ihren Präferenzen und Ihrem Verhalten', 'Customizing content and recommendations based on your preferences and behavior')}</li>
                  <li>{t('Audit & Überwachung:', 'Audit & Monitoring:')} {t('Führung von Audit-Trails, Überwachung der Compliance und Sicherstellung der Plattformintegrität', 'Maintaining audit trails, monitoring compliance, and ensuring platform integrity')}</li>
                </ul>
              </div>

              {/* Legal Basis - GDPR */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('4. Rechtsgrundlage der Verarbeitung (DSGVO)', '4. Legal Basis for Processing (GDPR)')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Für Nutzer in der Europäischen Union und anderen DSGVO-regulierten Rechtsräumen verarbeiten wir Ihre personenbezogenen Daten auf folgenden Rechtsgrundlagen:', 'For users in the European Union and other GDPR-regulated jurisdictions, we process your personal data based on the following legal grounds:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('Vertragserfüllung:', 'Contract Performance:')} {t('Verarbeitung, die zur Erbringung unserer Dienste und Erfüllung Ihrer Anfragen erforderlich ist', 'Processing necessary to perform our services and fulfill your requests')}</li>
                  <li>{t('Rechtliche Verpflichtung:', 'Legal Obligation:')} {t('Gesetzlich vorgeschriebene Verarbeitung (KYC/AML-Vorschriften, Steuerberichterstattung, Finanzvorschriften)', 'Processing required by law (KYC/AML regulations, tax reporting, financial regulations)')}</li>
                  <li>{t('Berechtigtes Interesse:', 'Legitimate Interest:')} {t('Verarbeitung zur Betrugsvorbeugung, Sicherheit, Plattformverbesserung und Geschäftsbetrieb', 'Processing for fraud prevention, security, platform improvement, and business operations')}</li>
                  <li>{t('Einwilligung:', 'Consent:')} {t('Verarbeitung basierend auf Ihrer ausdrücklichen Einwilligung für Marketing und optionale Funktionen', 'Processing based on your explicit consent for marketing communications and optional features')}</li>
                </ul>
              </div>

              {/* User Rights */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('5. Ihre Rechte', '5. Your Rights')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Je nach Rechtsraum haben Sie folgende Rechte bezüglich Ihrer personenbezogenen Daten:', 'Depending on your jurisdiction, you have the following rights regarding your personal data:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('Auskunftsrecht:', 'Right to Access:')} {t('Anforderung einer Kopie der über Sie gespeicherten personenbezogenen Daten', 'Request a copy of the personal data we hold about you')}</li>
                  <li>{t('Recht auf Berichtigung:', 'Right to Rectification:')} {t('Korrektur unrichtiger oder unvollständiger personenbezogener Daten', 'Correct inaccurate or incomplete personal data')}</li>
                  <li>{t('Recht auf Löschung:', 'Right to Erasure:')} {t('Anforderung der Löschung Ihrer personenbezogenen Daten (vorbehaltlich gesetzlicher Aufbewahrungspflichten)', 'Request deletion of your personal data (subject to legal retention requirements)')}</li>
                  <li>{t('Recht auf Einschränkung der Verarbeitung:', 'Right to Restrict Processing:')} {t('Einschränkung der Nutzung Ihrer Daten unter bestimmten Umständen', 'Limit how we use your data in certain circumstances')}</li>
                  <li>{t('Recht auf Datenübertragbarkeit:', 'Right to Data Portability:')} {t('Erhalt Ihrer Daten in einem strukturierten, gängigen Format und Übertragung an einen anderen Anbieter', 'Receive your data in a structured, commonly used format and transfer it to another provider')}</li>
                  <li>{t('Widerspruchsrecht:', 'Right to Object:')} {t('Widerspruch gegen die Verarbeitung Ihrer Daten für Marketing oder Profiling', 'Object to processing of your data for marketing or profiling purposes')}</li>
                  <li>{t('Recht auf Widerruf der Einwilligung:', 'Right to Withdraw Consent:')} {t('Widerruf der Einwilligung für optionale Verarbeitung jederzeit', 'Withdraw consent for optional processing at any time')}</li>
                  <li>{t('Beschwerderecht:', 'Right to Lodge a Complaint:')} {t('Einreichung einer Beschwerde bei Ihrer lokalen Datenschutzbehörde', 'File a complaint with your local data protection authority')}</li>
                </ul>
                <p className="text-lg leading-relaxed mt-4">
                  {t('Zur Ausübung dieser Rechte kontaktieren Sie uns unter ', 'To exercise any of these rights, please contact us at ')}<a href="mailto:support@delfinitx.com" className="text-primary hover:underline">support@delfinitx.com</a>{t(' mit Ihrem Anliegen. Wir antworten innerhalb von 30 Tagen.', ' with your request. We will respond within 30 days.')}
                </p>
              </div>

              {/* Data Security */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('6. Datensicherheit', '6. Data Security')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Wir setzen umfassende Sicherheitsmaßnahmen ein, um Ihre personenbezogenen Daten vor unbefugtem Zugriff, Änderung, Offenlegung oder Zerstörung zu schützen:', 'We implement comprehensive security measures to protect your personal data from unauthorized access, alteration, disclosure, or destruction:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('SOC2-Type-II-Zertifizierung:', 'SOC2 Type II Certification:')} {t('Unsere Infrastruktur und Prozesse sind nach SOC2 Type II geprüft und zertifiziert', 'Our infrastructure and processes are audited and certified to SOC2 Type II standards, ensuring security, availability, and confidentiality')}</li>
                  <li>{t('ISO-27001-Zertifizierung:', 'ISO 27001 Certification:')} {t('Wir halten die ISO-27001-Zertifizierung für Informationssicherheitsmanagementsysteme', 'We maintain ISO 27001 certification for information security management systems')}</li>
                  <li>{t('Verschlüsselung:', 'Encryption:')} {t('Alle Daten bei der Übertragung sind mit TLS 1.2+ verschlüsselt; sensible ruhende Daten mit AES-256', 'All data in transit is encrypted using TLS 1.2+ protocols; sensitive data at rest is encrypted using AES-256 encryption')}</li>
                  <li>{t('Zugriffskontrolle:', 'Access Controls:')} {t('Rollenbasierte Zugriffskontrolle (RBAC) beschränkt Mitarbeiterzugriff auf personenbezogene Daten nach dem Need-to-Know-Prinzip', 'Role-based access control (RBAC) limits employee access to personal data on a need-to-know basis')}</li>
                  <li>{t('Authentifizierung:', 'Authentication:')} {t('Multi-Faktor-Authentifizierung (MFA) für Kontoschutz verfügbar', 'Multi-factor authentication (MFA) available for account protection')}</li>
                  <li>{t('Regelmäßige Audits:', 'Regular Audits:')} {t('Periodische Sicherheitsbewertungen, Penetrationstests und Schwachstellen-Scans', 'Periodic security assessments, penetration testing, and vulnerability scanning')}</li>
                  <li>{t('Vorfallsreaktion:', 'Incident Response:')} {t('Dokumentierte Vorfallsreaktionsverfahren und Verletzungs-Benachrichtigungsprotokolle', 'Documented incident response procedures and breach notification protocols')}</li>
                </ul>
                <p className="text-lg leading-relaxed mt-4">
                  {t('Obwohl wir branchenübliche Sicherheitsmaßnahmen einsetzen, ist keine Übertragung über das Internet zu 100 % sicher. Wir können keine absolute Sicherheit garantieren; Sie nutzen unsere Dienste auf eigenes Risiko.', 'While we employ industry-standard security measures, no method of transmission over the Internet is 100% secure. We cannot guarantee absolute security, and you use our services at your own risk.')}
                </p>
              </div>

              {/* Data Sharing */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('7. Datenweitergabe & Offenlegung', '7. Data Sharing & Disclosure')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Wir können Ihre personenbezogenen Daten in folgenden Fällen weitergeben:', 'We may share your personal data in the following circumstances:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('Dienstleister:', 'Service Providers:')} {t('Drittanbieter für Zahlungsabwicklung, Identitätsverifizierung, Kundensupport, Analytik und Hosting (alle an Vertraulichkeitsvereinbarungen gebunden)', 'Third-party vendors who assist with payment processing, identity verification, customer support, analytics, and hosting (all bound by confidentiality agreements)')}</li>
                  <li>{t('Gesetzliche Anforderungen:', 'Legal Requirements:')} {t('Bei gesetzlicher Anforderung, Gerichtsbeschluss oder behördlicher Anfrage (wir benachrichtigen Sie, sofern gesetzlich zulässig)', 'When required by law, court order, or government request (we will notify you unless legally prohibited)')}</li>
                  <li>{t('Betrugsvorbeugung:', 'Fraud Prevention:')} {t('Weitergabe an Betrugserkennungsdienste und Finanzinstitute zur Verhinderung unbefugten Zugriffs', 'Sharing with fraud detection services and financial institutions to prevent unauthorized access')}</li>
                  <li>{t('Regulatorische Compliance:', 'Regulatory Compliance:')} {t('Offenlegung gegenüber Finanzbehörden, Steuerbehörden und AML/KYC-Compliance-Stellen', 'Disclosure to financial regulators, tax authorities, and AML/KYC compliance bodies')}</li>
                  <li>{t('Unternehmensübertragungen:', 'Business Transfers:')} {t('Bei Fusion, Übernahme, Insolvenz oder Vermögensverkauf (mit Benachrichtigung)', 'In the event of merger, acquisition, bankruptcy, or sale of assets (with notice to you)')}</li>
                  <li>{t('Ihre Einwilligung:', 'Your Consent:')} {t('Wenn Sie uns ausdrücklich zur Weitergabe Ihrer Daten an Dritte autorisieren', 'When you explicitly authorize us to share your data with third parties')}</li>
                </ul>
                <p className="text-lg leading-relaxed mt-4">
                  {t('Wir verkaufen Ihre personenbezogenen Daten nicht an Dritte zu Marketingzwecken.', 'We do not sell your personal data to third parties for marketing purposes.')}
                </p>
              </div>

              {/* Data Retention */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('8. Datenaufbewahrungsrichtlinie', '8. Data Retention Policy')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Wir bewahren Ihre personenbezogenen Daten so lange auf, wie zur Erbringung unserer Dienste und Erfüllung gesetzlicher Verpflichtungen erforderlich:', 'We retain your personal data for as long as necessary to provide our services and comply with legal obligations:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('Kontodaten:', 'Account Data:')} {t('Während der Kontolaufzeit und 7 Jahre nach Kontoschließung aus Compliance-Gründen', 'Retained while your account is active and for 7 years after account closure for regulatory compliance')}</li>
                  <li>{t('Transaktionsaufzeichnungen:', 'Transaction Records:')} {t('7 Jahre zur Einhaltung von Finanzvorschriften und Steueranforderungen', 'Retained for 7 years to comply with financial regulations and tax requirements')}</li>
                  <li>{t('KYC-Dokumente:', 'KYC Documents:')} {t('7 Jahre nach Kontoschließung oder letzter Transaktion für AML/KYC-Compliance', 'Retained for 7 years after account closure or final transaction for AML/KYC compliance')}</li>
                  <li>{t('Kommunikationsaufzeichnungen:', 'Communication Records:')} {t('3 Jahre für Kundenservice und Streitbeilegung', 'Retained for 3 years for customer service and dispute resolution')}</li>
                  <li>{t('Protokolldaten:', 'Log Data:')} {t('90 Tage für Sicherheit und Fehlerbehebung', 'Retained for 90 days for security and troubleshooting purposes')}</li>
                  <li>{t('Marketingdaten:', 'Marketing Data:')} {t('Bis zum Abbestellen oder Widerruf der Einwilligung', 'Retained until you unsubscribe or withdraw consent')}</li>
                </ul>
                <p className="text-lg leading-relaxed mt-4">
                  {t('Nach Ablauf der Aufbewahrungsfrist löschen oder anonymisieren wir Ihre Daten sicher. Aggregierte oder anonymisierte Daten können jedoch unbegrenzt für Analysezwecke aufbewahrt werden.', 'After the retention period expires, we securely delete or anonymize your data. However, we may retain aggregated or anonymized data indefinitely for analytics and research purposes.')}
                </p>
              </div>

              {/* Cookies & Tracking */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('9. Cookies & Tracking-Technologien', '9. Cookies & Tracking Technologies')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Wir verwenden Cookies und ähnliche Tracking-Technologien zur Verbesserung Ihrer Erfahrung:', 'We use cookies and similar tracking technologies to enhance your experience:')}
                </p>
                <ul className="list-disc list-inside space-y-3 text-lg leading-relaxed ml-2">
                  <li>{t('Sitzungs-Cookies:', 'Session Cookies:')} {t('Temporäre Cookies, die beim Schließen des Browsers ablaufen; für Authentifizierung und Sitzungsverwaltung', 'Temporary cookies that expire when you close your browser; used for authentication and session management')}</li>
                  <li>{t('Dauerhafte Cookies:', 'Persistent Cookies:')} {t('Langfristige Cookies auf Ihrem Gerät; zum Speichern von Präferenzen und Login-Informationen', 'Long-term cookies that remain on your device; used for remembering preferences and login information')}</li>
                  <li>{t('Analyse-Cookies:', 'Analytics Cookies:')} {t('Verfolgen Nutzungsmuster und Benutzerverhalten zur Verbesserung der Plattform', 'Track usage patterns and user behavior to improve platform functionality')}</li>
                  <li>{t('Sicherheits-Cookies:', 'Security Cookies:')} {t('Verhindern Betrug und unbefugten Zugriff', 'Prevent fraud and unauthorized access')}</li>
                </ul>
                <p className="text-lg leading-relaxed mt-4">
                  {t('Sie können Cookies über Ihre Browser-Einstellungen steuern. Das Deaktivieren von Cookies kann die Plattformfunktionalität beeinträchtigen. Wir berücksichtigen „Do Not Track"-Signale, wo anwendbar.', 'You can control cookies through your browser settings. Disabling cookies may affect platform functionality. We respect "Do Not Track" signals where applicable.')}
                </p>
              </div>

              {/* Third-Party Links */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('10. Links zu Drittanbietern', '10. Third-Party Links')}</h2>
                <p className="text-lg leading-relaxed">
                  {t('Unsere Website kann Links zu Drittanbieter-Websites und -Diensten enthalten, die nicht von delfinitx betrieben werden. Diese Datenschutzrichtlinie gilt nicht für Drittanbieter-Websites, und wir sind nicht für deren Datenschutzpraktiken verantwortlich. Wir empfehlen, die Datenschutzrichtlinien Dritter zu prüfen, bevor Sie personenbezogene Daten angeben.', 'Our website may contain links to third-party websites and services that are not operated by delfinitx. This Privacy Policy does not apply to third-party websites, and we are not responsible for their privacy practices. We encourage you to review the privacy policies of any third-party services before providing your personal information.')}
                </p>
              </div>

              {/* Children's Privacy */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('11. Datenschutz für Kinder', "11. Children's Privacy")}</h2>
                <p className="text-lg leading-relaxed">
                  {t('delfinitx richtet sich nicht an Personen unter 18 Jahren. Wir erfassen wissentlich keine personenbezogenen Daten von Personen unter 18. Wenn wir erfahren, dass wir Daten einer Person unter 18 erhoben haben, löschen wir diese umgehend und kündigen das Konto. Wenn Sie glauben, dass wir Daten eines Kindes erhoben haben, kontaktieren Sie uns sofort unter ', 'delfinitx is not intended for individuals under 18 years of age. We do not knowingly collect personal data from children under 18. If we become aware that we have collected data from a child under 18, we will promptly delete such information and terminate the child\'s account. If you believe we have collected data from a child, please contact us immediately at ')}<a href="mailto:support@delfinitx.com" className="text-primary hover:underline">support@delfinitx.com</a>.
                </p>
              </div>

              {/* International Transfers */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('12. Internationale Datenübertragungen', '12. International Data Transfers')}</h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Ihre personenbezogenen Daten können in andere Länder als Ihr Wohnsitzland übertragen, dort gespeichert und verarbeitet werden. Diese Länder können andere Datenschutzgesetze haben. Durch die Nutzung von delfinitx stimmen Sie der Übertragung Ihrer Informationen in Länder außerhalb Ihres Wohnsitzlandes zu.', 'Your personal data may be transferred to, stored in, and processed in countries other than your country of residence. These countries may have data protection laws that differ from your home country. By using delfinitx, you consent to the transfer of your information to countries outside your country of residence, which may include countries that do not have the same data protection laws.')}
                </p>
                <p className="text-lg leading-relaxed">
                  {t('Für EU-Bewohner setzen wir angemessene Garantien wie Standardvertragsklauseln (SCC) ein, um einen angemessenen Schutz Ihrer Daten bei internationalen Übertragungen zu gewährleisten.', 'For EU residents, we implement appropriate safeguards such as Standard Contractual Clauses (SCCs) to ensure adequate protection of your data during international transfers.')}
                </p>
              </div>

              {/* Policy Changes */}
              <div className="mb-12">
                <h2 className="text-2xl font-bold mb-4">{t('13. Änderungen dieser Datenschutzrichtlinie', '13. Changes to This Privacy Policy')}</h2>
                <p className="text-lg leading-relaxed">
                  {t('Wir können diese Datenschutzrichtlinie von Zeit zu Zeit aktualisieren, um Änderungen in unseren Praktiken, der Technologie, gesetzlichen Anforderungen oder anderen Faktoren widerzuspiegeln. Wir werden Sie über wesentliche Änderungen informieren, indem wir die aktualisierte Richtlinie auf unserer Website veröffentlichen und das Datum „Zuletzt aktualisiert" anpassen. Ihre fortgesetzte Nutzung von delfinitx nach solchen Änderungen gilt als Zustimmung zur aktualisierten Datenschutzrichtlinie.', 'We may update this Privacy Policy from time to time to reflect changes in our practices, technology, legal requirements, or other factors. We will notify you of material changes by posting the updated policy on our website and updating the "Last updated" date. Your continued use of delfinitx after such modifications constitutes your acceptance of the updated Privacy Policy. We encourage you to review this policy periodically to stay informed about how we protect your information.')}
                </p>
              </div>

              {/* Contact Information */}
              <div className="mb-12 p-6 bg-primary/10 border border-primary/20 rounded-lg">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <Mail className="w-6 h-6 text-primary" />
                  {t('14. Kontakt', '14. Contact Us')}
                </h2>
                <p className="text-lg leading-relaxed mb-4">
                  {t('Bei Fragen, Bedenken oder Anfragen zu dieser Datenschutzrichtlinie kontaktieren Sie uns:', 'If you have questions, concerns, or requests regarding this Privacy Policy or our privacy practices, please contact us:')}
                </p>
                <div className="space-y-3 text-lg">
                  <p>{t('E-Mail:', 'Email:')} <a href="mailto:support@delfinitx.com" className="text-primary hover:underline">support@delfinitx.com</a></p>
                  <p>{t('Unternehmen:', 'Company:')} delfinitx</p>
                  <p>{t('Antwortzeit:', 'Response Time:')} {t('Wir antworten innerhalb von 30 Tagen', 'We will respond to your inquiry within 30 days')}</p>
                </div>
                <p className="text-lg leading-relaxed mt-4">
                  {t('EU-Bewohner haben zudem das Recht, eine Beschwerde bei ihrer lokalen Datenschutzbehörde einzureichen, wenn sie der Meinung sind, dass wir Ihre Privatsphärerechte verletzt haben.', 'For EU residents, you also have the right to lodge a complaint with your local data protection authority if you believe we have violated your privacy rights.')}
                </p>
              </div>

              {/* Navigation */}
              <div className="flex flex-col sm:flex-row gap-4 pt-8 border-t border-border">
                <Button asChild variant="outline">
                  <Link to="/">{t('Zurück zur Startseite', 'Back to Home')}</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/contact">{t('Kontakt aufnehmen', 'Contact Us')}</Link>
                </Button>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default PrivacyPolicyPage;
