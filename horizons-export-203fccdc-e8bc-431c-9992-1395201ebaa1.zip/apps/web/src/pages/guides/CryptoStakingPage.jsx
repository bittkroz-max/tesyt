import React from 'react';
import { Coins, TrendingUp, ShieldCheck, Wallet, AlertTriangle, Layers } from 'lucide-react';
import GuideArticleLayout from '@/components/GuideArticleLayout.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const CryptoStakingPage = () => {
  const { t } = useLanguage();
  const sections = [
    {
      heading: t('Was ist Crypto Staking?', 'What Is Crypto Staking?'),
      icon: Coins,
      paragraphs: [
        t('Staking ist der Prozess, bei dem Kryptowährungsbestände gesperrt werden, um den Betrieb und die Sicherheit eines auf Proof of Stake (PoS) basierenden Blockchain-Netzwerks zu unterstützen. Als Gegenleistung für das Bereitstellen Ihrer Assets belohnt Sie das Netzwerk mit zusätzlichen Token – ähnlich wie beim Verdienen von Zinsen auf einem Sparkonto, jedoch basierend auf Blockchain-Ökonomie statt auf traditionellem Bankwesen.', 'Staking is the process of locking up cryptocurrency holdings to help operate and secure a blockchain network built on Proof of Stake (PoS) consensus. In exchange for committing your assets, the network rewards you with additional tokens — similar to earning interest on a savings account, but rooted in blockchain economics rather than traditional banking.'),
        t('Anstatt auf energieintensive Mining-Hardware zu setzen, wählen PoS-Netzwerke Validatoren basierend auf der Menge an gestakter Kryptowährung aus. Je mehr Sie staken, desto höher die Wahrscheinlichkeit, für die Validierung von Transaktionen ausgewählt zu werden und Belohnungen zu verdienen.', 'Instead of relying on energy-intensive mining hardware, PoS networks select validators based on the amount of cryptocurrency they have staked. The more you stake, the higher your probability of being chosen to validate transactions and earn rewards.'),
      ],
    },
    {
      heading: t('Wie funktioniert Staking?', 'How Does Staking Work?'),
      icon: Layers,
      subheading: t('Von der Einzahlung bis zur Belohnung in vier Schritten', 'From deposit to reward, in four steps'),
      paragraphs: [
        t('Wenn Sie ein Asset staken, werden Ihre Token dem Netzwerk als Sicherheit hinterlegt. Validatoren – die Teilnehmer, die für die Bestätigung von Transaktionen und die Erstellung neuer Blöcke verantwortlich sind – werden teilweise basierend auf ihrem gestakten Betrag ausgewählt. Verhält sich ein Validator ehrlich, erhält er Belohnungen; verhält er sich böswillig, kann ein Teil seines Einsatzes verwirkt werden – ein Mechanismus, der als „Slashing“ bekannt ist.', 'When you stake an asset, your tokens are committed to the network as collateral. Validators — the participants responsible for confirming transactions and creating new blocks — are chosen partly based on their staked amount. If a validator behaves honestly, they receive rewards; if they act maliciously, a portion of their stake can be forfeited, a mechanism known as "slashing."'),
      ],
      list: [
        { title: t('Asset wählen', 'Choose an asset'), description: t('wählen Sie eine Proof-of-Stake-Kryptowährung wie Ethereum, Cardano oder Solana', 'select a Proof of Stake cryptocurrency such as Ethereum, Cardano, or Solana') },
        { title: t('Delegieren oder Validator betreiben', 'Delegate or run a validator'), description: t('direkt über eine Plattform staken oder an einen professionellen Validator delegieren', 'stake directly through a platform or delegate to a professional validator') },
        { title: t('Netzwerk bestätigt Blöcke', 'Network confirms blocks'), description: t('Validatoren werden proportional zur Einsatzhöhe ausgewählt, um neue Blöcke vorzuschlagen und zu bestätigen', 'validators are selected to propose and confirm new blocks in proportion to stake size') },
        { title: t('Belohnungen verdienen', 'Earn rewards'), description: t('Belohnungen werden regelmäßig ausgezahlt, typischerweise als annualisierte prozentuale Rendite', 'rewards are distributed periodically, typically annualized as a percentage yield') },
      ],
    },
    {
      heading: t('Vorteile des Staking', 'Benefits of Staking'),
      icon: TrendingUp,
      paragraphs: [
        t('Staking bietet eine attraktive Kombination aus passivem Einkommen und aktiver Teilnahme an der Netzwerksicherheit und ist damit eine der zugänglichsten Möglichkeiten, sich mit Blockchain-Technologie über den einfachen Handel hinaus zu beschäftigen.', 'Staking offers a compelling combination of passive income potential and active participation in network security, making it one of the most accessible ways to engage with blockchain technology beyond simple trading.'),
      ],
      list: [
        { title: t('Passive Belohnungen', 'Passive rewards'), description: t('Rendite auf Bestände verdienen, die Sie bereits halten, ohne aktiven Handel', 'earn yield on assets you already hold, without active trading') },
        { title: t('Niedriger Energieverbrauch', 'Lower energy footprint'), description: t('PoS verbraucht deutlich weniger Energie als Proof-of-Work-Mining', 'PoS consumes dramatically less energy than Proof of Work mining') },
        { title: t('Netzwerkteilnahme', 'Network participation'), description: t('direkt zur Sicherheit und Dezentralisierung der Blockchain beitragen', 'contribute directly to the security and decentralization of the blockchain') },
        { title: t('Zinseszins-Potenzial', 'Compounding potential'), description: t('viele Plattformen erlauben automatisches Wieder-Staken für Zinseszinswachstum', 'many platforms allow rewards to be automatically restaked for compound growth') },
      ],
    },
    {
      heading: t('Zu verstehende Risiken', 'Risks to Understand'),
      icon: AlertTriangle,
      paragraphs: [
        t('Wie jede Anlagetätigkeit birgt Staking Risiken. Gestakte Assets unterliegen oft Sperrfristen oder „Unbonding“-Zeiträumen, während denen sie nicht abgehoben oder verkauft werden können, was Halter möglicher Kursschwankungen aussetzt. Validatoren, die sich unehrlich verhalten, können durch Slashing bestraft werden, was auch Delegatoren betreffen kann.', 'Like any investment activity, staking carries risk. Staked assets are often subject to lock-up or "unbonding" periods during which they cannot be withdrawn or sold, exposing holders to potential price volatility. Validators who behave dishonestly can be penalized through slashing, which may affect delegators as well.'),
        t('Es ist wichtig, die genauen Bedingungen eines Staking-Programms zu prüfen – einschließlich Mindestsperrdauer, Belohnungshäufigkeit und Validator-Reputation – bevor Sie Mittel bereitstellen.', 'It is important to research the specific terms of any staking program — including minimum lock-up duration, reward frequency, and validator reputation — before committing funds.'),
      ],
    },
    {
      heading: t('Sicher einsteigen', 'Getting Started Securely'),
      icon: ShieldCheck,
      paragraphs: [
        t('Die Wahl einer seriösen, sicherheitsgeprüften Plattform ist die wichtigste Entscheidung auf Ihrem Staking-Weg. Achten Sie auf Anbieter mit transparenten Belohnungsstrukturen, starken Verwahrungspraktiken und überprüfbaren Compliance-Zertifizierungen.', 'Choosing a reputable, security-audited platform is the most important decision in your staking journey. Look for providers with transparent reward structures, strong custody practices, and verifiable compliance certifications.'),
      ],
    },
    {
      heading: t('Staking auf delfinitx', 'Staking on delfinitx'),
      icon: Wallet,
      paragraphs: [
        t('delfinitx kombiniert Sicherheit auf Unternehmensebene mit einem übersichtlichen Staking-Erlebnis und gibt Ihnen klaren Einblick in Belohnungsraten, Sperrfristen und Portfolio-Performance – alles über ein einziges Dashboard.', 'delfinitx combines enterprise-grade security with a streamlined staking experience, giving you clear visibility into reward rates, lock-up terms, and portfolio performance — all from a single dashboard.'),
      ],
    },
  ];

  return (
    <GuideArticleLayout
      metaTitle={t('Was ist Crypto Staking? Vollständiger Leitfaden - delfinitx', 'What Is Crypto Staking? Complete Guide - delfinitx')}
      metaDescription={t('Erfahren Sie, was Crypto Staking ist, wie es funktioniert, seine Vorteile und Risiken und wie Sie sicher auf delfinitx staken können.', 'Learn what crypto staking is, how it works, its benefits and risks, and how to start staking securely on delfinitx.')}
      category={t('Anfänger', 'Beginners')}
      difficulty={t('Einfach', 'Easy')}
      readingTime={8}
      date={t('15. April 2026', 'April 15, 2026')}
      title={t('Was ist Crypto Staking?', 'What Is Crypto Staking?')}
      intro={t('Verstehen Sie, wie Staking passive Belohnungen durch die Sicherung von Blockchain-Netzwerken ermöglicht und warum es zu einem Grundpfeiler modernen, nachhaltigen Investierens geworden ist.', 'Understand how staking lets you earn passive rewards by securing blockchain networks, and why it has become a cornerstone of modern sustainable investing.')}
      heroImage="https://images.hostinger.com/8670280b-efcb-4356-98fd-6b17dfbd682c.png"
      heroAlt={t('Leuchtende lila Krypto-Münzen, die sich stapeln und Staking-Belohnungen symbolisieren', 'Glowing purple crypto coins stacking, representing crypto staking rewards')}
      sections={sections}
      ctaTitle={t('Bereit, Staking-Belohnungen zu verdienen?', 'Ready to start earning staking rewards?')}
      ctaDescription={t('Erstellen Sie Ihr delfinitx-Konto und lassen Sie Ihr Krypto mit sicherem, transparentem Staking für sich arbeiten.', 'Create your delfinitx account and put your crypto to work with secure, transparent staking.')}
    />
  );
};

export default CryptoStakingPage;
