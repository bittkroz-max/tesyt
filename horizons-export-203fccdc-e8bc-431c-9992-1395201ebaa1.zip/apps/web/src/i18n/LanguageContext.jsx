import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';

const LANG_KEY = 'delfinitx_lang';
export const SUPPORTED_LANGS = ['de', 'en'];

const LanguageContext = createContext({
  lang: 'de',
  setLang: () => {},
  toggleLang: () => {},
  t: (de) => de,
});

function detectInitialLang() {
  try {
    const stored = localStorage.getItem(LANG_KEY);
    if (stored === 'de' || stored === 'en') return stored;
  } catch (_) { /* ignore */ }
  return 'de';
}

export const LanguageProvider = ({ children }) => {
  const [lang, setLangState] = useState(detectInitialLang);

  useEffect(() => {
    document.documentElement.lang = lang;
    try { localStorage.setItem(LANG_KEY, lang); } catch (_) { /* ignore */ }
  }, [lang]);

  const setLang = useCallback((next) => {
    if (next === 'de' || next === 'en') setLangState(next);
  }, []);

  const toggleLang = useCallback(() => {
    setLangState((prev) => (prev === 'de' ? 'en' : 'de'));
  }, []);

  // t(de, en) — German is always the first argument and the primary language.
  const t = useCallback((de, en) => (lang === 'en' ? (en ?? de) : de), [lang]);

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);

export default LanguageContext;
