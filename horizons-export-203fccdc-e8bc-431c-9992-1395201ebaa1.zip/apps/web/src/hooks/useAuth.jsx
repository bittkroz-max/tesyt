import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import pb from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(pb.authStore.record);

  useEffect(() => {
    const unsub = pb.authStore.onChange((_token, record) => setUser(record));
    return unsub;
  }, []);

  // Refresh the auth record so status/role changes (e.g. admin approval)
  // are reflected without requiring a re-login.
  const refresh = useCallback(async () => {
    if (!pb.authStore.isValid) return null;
    try {
      const rec = await pb.collection('users').authRefresh();
      setUser(rec.record);
      return rec.record;
    } catch (e) {
      return pb.authStore.record;
    }
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await pb.collection('users').authWithPassword(email, password);
    return res.record;
  }, []);

  const signup = useCallback(async ({ email, password, name }) => {
    await pb.collection('users').create({
      email,
      password,
      passwordConfirm: password,
      name,
      role: 'client',
      status: 'pending',
    });
    await pb.collection('users').authWithPassword(email, password);
    try { await pb.collection('users').requestVerification(email); } catch (e) { /* noop */ }
    return pb.authStore.record;
  }, []);

  const logout = useCallback(() => {
    pb.authStore.clear();
    setUser(null);
  }, []);

  const value = {
    user,
    isAuthed: pb.authStore.isValid,
    isAdmin: user?.role === 'admin',
    isApproved: user?.status === 'approved',
    isVerified: !!user?.verified,
    login,
    signup,
    logout,
    refresh,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
