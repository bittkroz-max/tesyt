/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    let admin = null;
    try {
      admin = app.findAuthRecordByEmail("users", "support@depoz-company.digital");
    } catch (_) {
      admin = null;
    }
    if (admin) {
      admin.setEmail("support@delfinitx.com");
      admin.set("name", "delfinitx Team");
      app.save(admin);
    }
  },
  (app) => {
    let admin = null;
    try {
      admin = app.findAuthRecordByEmail("users", "support@delfinitx.com");
    } catch (_) {
      admin = null;
    }
    if (admin) {
      admin.setEmail("support@depoz-company.digital");
      admin.set("name", "TRZ Online Platform Team");
      app.save(admin);
    }
  },
);
