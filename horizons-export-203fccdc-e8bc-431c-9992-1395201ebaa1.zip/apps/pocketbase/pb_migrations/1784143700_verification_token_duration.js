/// <reference path="../pb_data/types.d.ts" />

// Ensure the email-verification token stays valid for 7 days so a client
// clicking the link some time after registering can still verify.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    if (users.verificationToken) {
      users.verificationToken.duration = 604800; // 7 days in seconds
    }
    app.save(users);
  },
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    if (users.verificationToken) {
      users.verificationToken.duration = 259200; // PocketBase default (3 days)
    }
    app.save(users);
  },
);
