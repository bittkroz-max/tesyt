/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    try {
      const admin = app.findAuthRecordByEmail("users", "support@depoz-company.digital");
      if (admin.get("name") === "Administrator") {
        admin.set("name", "TRZ Online Platform");
        app.save(admin);
      }
    } catch (_) { /* noop */ }
  },
  (app) => {
    try {
      const admin = app.findAuthRecordByEmail("users", "support@depoz-company.digital");
      if (admin.get("name") === "TRZ Online Platform") {
        admin.set("name", "Administrator");
        app.save(admin);
      }
    } catch (_) { /* noop */ }
  },
);
