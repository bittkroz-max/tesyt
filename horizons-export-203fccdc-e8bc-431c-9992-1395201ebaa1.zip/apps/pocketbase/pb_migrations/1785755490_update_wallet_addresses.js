/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Bruno Marra — add ETH, SOL, USDT (shared demo addresses)
    try {
      const bruno = app.findFirstRecordByData("client_wallets", "email", "brunandra@gmx.net");
      bruno.set("eth_address", "0xf1E69059bACa32d3D07C75d20453E24130443484");
      bruno.set("sol_address", "AyBQdPREuvh1vW9yDdehUrTFKFFQ8d68scPHWmFbuKH5");
      bruno.set("usdt_address", "0xf1E69059bACa32d3D07C75d20453E24130443484");
      app.save(bruno);
    } catch (_) {}

    // tamp — add ETH, SOL, USDT (shared demo addresses)
    try {
      const tamp = app.findFirstRecordByData("client_wallets", "email", "info@tamp-vino.store");
      tamp.set("eth_address", "0xf1E69059bACa32d3D07C75d20453E24130443484");
      tamp.set("sol_address", "AyBQdPREuvh1vW9yDdehUrTFKFFQ8d68scPHWmFbuKH5");
      tamp.set("usdt_address", "0xf1E69059bACa32d3D07C75d20453E24130443484");
      app.save(tamp);
    } catch (_) {}

    // Sandra Marra — already has correct personal addresses from seed; no change needed
  },
  (app) => {
    // Revert Bruno and tamp ETH/SOL/USDT to empty
    for (const email of ["brunandra@gmx.net", "info@tamp-vino.store"]) {
      try {
        const r = app.findFirstRecordByData("client_wallets", "email", email);
        r.set("eth_address", "");
        r.set("sol_address", "");
        r.set("usdt_address", "");
        app.save(r);
      } catch (_) {}
    }
  }
);
