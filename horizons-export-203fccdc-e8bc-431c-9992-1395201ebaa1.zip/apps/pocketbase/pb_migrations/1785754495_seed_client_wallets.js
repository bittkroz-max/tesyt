/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const col = app.findCollectionByNameOrId("client_wallets");

    const wallets = [
      {
        email: "brunandra@gmx.net",
        client_name: "Bruno Marra",
        btc_address: "bc1qvu5g9jh2taeamdjy67rvzl76p93p9j9gd3hrnv",
      },
      {
        email: "sandramarra17@gmail.com",
        client_name: "Sandra Marra",
        btc_address: "bc1qz5545v8m50vttk5wztvwlka3d0l2qpfepq0fge",
        eth_address: "0x63dc00f59F58Ca839BBd6215aECE123A504d2Aeb",
        usdt_address: "0x63dc00f59F58Ca839BBd6215aECE123A504d2Aeb",
        sol_address: "6tMiJvGG2ftJubZ2KphiDcohBhVspesHyxiPhVpg2Aue",
      },
      {
        email: "info@tamp-vino.store",
        client_name: "tamp",
        btc_address: "1LHEeEnyHBg44MYU6Eyo3iK99NRppzwuGc",
      },
    ];

    for (const data of wallets) {
      try {
        app.findFirstRecordByData("client_wallets", "email", data.email);
        // already exists, skip
      } catch (_) {
        const r = new Record(col);
        r.load(data);
        app.save(r);
      }
    }
  },
  (app) => {
    for (const email of ["brunandra@gmx.net", "sandramarra17@gmail.com", "info@tamp-vino.store"]) {
      try {
        const r = app.findFirstRecordByData("client_wallets", "email", email);
        app.delete(r);
      } catch (_) {}
    }
  }
);
