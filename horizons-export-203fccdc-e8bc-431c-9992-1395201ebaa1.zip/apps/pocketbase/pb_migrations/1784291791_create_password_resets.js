/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    let collection;
    try {
      collection = app.findCollectionByNameOrId("password_resets");
    } catch (_) {
      collection = null;
    }

    if (!collection) {
      collection = new Collection({
        type: "base",
        name: "password_resets",
        // Nobody accesses this collection via REST directly — only the
        // superuser-context pb_hooks routes touch it (bypasses rules).
        listRule: null,
        viewRule: null,
        createRule: null,
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: "token", type: "text", required: true, max: 100 },
          {
            name: "user",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "expiresAt", type: "date", required: true },
          { name: "used", type: "bool" },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_password_resets_token ON password_resets (token)",
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("password_resets");
      app.delete(collection);
    } catch (_) { /* noop */ }
  },
);
