/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // 1. Ensure Sandra Marra's user account is approved
    try {
      const sandra = app.findFirstRecordByFilter("users", "email = 'sandramarra17@gmail.com'");
      if (sandra.getString("status") !== "approved") {
        sandra.set("status", "approved");
        sandra.set("approvedAt", new Date().toISOString());
        app.save(sandra);
        console.log("[Sandra] User account approved.");
      } else {
        console.log("[Sandra] User account already approved.");
      }
    } catch (e) {
      console.log("[Sandra] User account not found in users collection:", e.message);
    }

    // 2. Ensure Sandra's wallet addresses are correct
    try {
      const wallet = app.findFirstRecordByData("client_wallets", "email", "sandramarra17@gmail.com");
      wallet.set("client_name", "Sandra Marra");
      wallet.set("btc_address", "bc1qz5545v8m50vttk5wztvwlka3d0l2qpfepq0fge");
      wallet.set("eth_address", "0x63dc00f59F58Ca839BBd6215aECE123A504d2Aeb");
      wallet.set("sol_address", "6tMiJvGG2ftJubZ2KphiDcohBhVspesHyxiPhVpg2Aue");
      wallet.set("usdt_address", "0x63dc00f59F58Ca839BBd6215aECE123A504d2Aeb");
      wallet.set("btc_zpub", "zpub6rNwj46AvgAj3kKt4LmN9MuCmC9tHqba6FouVDG4vtX1UfKMzipnwYed39LKJnWSDvbxESbULvgMtgtEksBxET9bCYaUMi4kfUp4o8T1xkW");
      app.save(wallet);
      console.log("[Sandra] Wallet addresses updated/confirmed.");
    } catch (e) {
      console.log("[Sandra] Wallet record not found:", e.message);
    }
  },
  (app) => {
    // No-op down: we don't want to un-approve or clear addresses on revert
  }
);
