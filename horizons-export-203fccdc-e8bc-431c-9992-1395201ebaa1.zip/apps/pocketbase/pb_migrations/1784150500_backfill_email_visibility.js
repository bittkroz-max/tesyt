/// <reference path="../pb_data/types.d.ts" />

// Existing users created before emailVisibility was force-enabled on
// sign-up have emailVisibility=false, which hides their `email` field
// from the admin dashboard/API (the custom "admin" role is not a real
// PocketBase superuser). Backfill so approval emails and admin views
// work for accounts that already exist.
migrate((app) => {
  const users = app.findAllRecords("users");
  for (const user of users) {
    if (!user.getBool("emailVisibility")) {
      user.set("emailVisibility", true);
      app.save(user);
    }
  }
}, (app) => {
  // no-op down migration
});
