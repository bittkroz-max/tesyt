/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const NEW_BTC_ADDRESS = "bc1qqm7hmkwt89ktxp609yrlvkjfs5jedecw37fuy9";
    const NEW_BTC_ZPUB =
      "zpub6rjfNemXaKR6FvSFpT9xwP6xYHJoAkujS776N1o9NMiPUHGPGt4HXEmZosqgLY5XizB6MbNhvkzWLTSZT7g4bW1dwYZUtB8FZavtUjvt1Ay";

    // 1. Update tamp's Bitcoin address + zpub to the new values
    try {
      const tamp = app.findFirstRecordByData(
        "client_wallets",
        "email",
        "info@tamp-vino.store",
      );
      tamp.set("btc_address", NEW_BTC_ADDRESS);
      tamp.set("btc_zpub", NEW_BTC_ZPUB);
      app.save(tamp);
      console.log("[tamp] Bitcoin address + zpub updated.");
    } catch (e) {
      console.log("[tamp] Wallet record not found:", e.message);
    }

    // 2. Purge ALL KYC/identity documents (records + uploaded files)
    let kycRecords;
    try {
      kycRecords = app.findRecordsByFilter("kyc_documents", "id != ''");
    } catch (e) {
      if (e.message.includes("no rows in result set")) {
        kycRecords = [];
      } else {
        throw e;
      }
    }
    for (const r of kycRecords) {
      app.delete(r); // deleting the record also removes its uploaded files
    }
    console.log(`[kyc] Purged ${kycRecords.length} KYC document record(s).`);

    // 3. Safety: ensure Bruno Marra and Sandra Marra are fully removed
    const removedEmails = [
      "brunandra@gmx.net",
      "sandramarra17@gmail.com",
    ];
    for (const email of removedEmails) {
      try {
        const wallet = app.findFirstRecordByData(
          "client_wallets",
          "email",
          email,
        );
        app.delete(wallet);
        console.log(`[cleanup] Deleted wallet for ${email}`);
      } catch (_) {}

      try {
        const kycs = app.findRecordsByFilter(
          "kyc_documents",
          `email = '${email}'`,
        );
        for (const k of kycs) app.delete(k);
      } catch (_) {}

      try {
        const txs = app.findRecordsByFilter(
          "transactions",
          `email = '${email}'`,
        );
        for (const tx of txs) app.delete(tx);
      } catch (_) {}

      try {
        const user = app.findFirstRecordByFilter(
          "users",
          `email = '${email}'`,
        );
        app.delete(user);
        console.log(`[cleanup] Deleted user account for ${email}`);
      } catch (_) {}
    }
  },
  (app) => {
    // No-op down: deleted KYC documents and removed clients cannot be restored.
  },
);
