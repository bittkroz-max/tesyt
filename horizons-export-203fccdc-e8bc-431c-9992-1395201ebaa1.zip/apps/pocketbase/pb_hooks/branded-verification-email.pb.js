/// <reference path="../pb_data/types.d.ts" />

// Brands the built-in PocketBase email-verification message sent when the
// frontend calls pb.collection('users').requestVerification(email). The
// "Verify" button links to our own in-app confirmation page instead of the
// default PocketBase admin UI route.
onMailerRecordVerificationSend((e) => {
  // Build the verification link from THIS instance's configured URL so the
  // token is always validated on the same PocketBase instance that issued it.
  // settings.meta.appURL points at the PocketBase API path
  // (e.g. https://<host>/hcgi/platform); the frontend lives at the site root,
  // so strip the trailing "/hcgi/..." segment to get the site origin.
  let appUrl = "https://delfinitx.com";
  try {
    const configured = $app.settings().meta.appURL || "";
    if (configured) {
      appUrl = configured.replace(/\/hcgi\/.*$/, "").replace(/\/+$/, "");
    }
  } catch (_) {
    // keep fallback
  }

  const link = `${appUrl}/auth/confirm-verification/${e.meta.token}`;
  const name = e.record.get("name") || "there";

  // Only override the display name — keep the platform-configured sender
  // address intact. Replacing the whole `from` object (dropping `address`)
  // makes the message have no valid sender and silently fails to deliver.
  if (e.message.from && typeof e.message.from === "object") {
    e.message.from.name = "delfinitx";
  } else {
    e.message.from = { name: "delfinitx" };
  }
  e.message.subject = "Welcome to delfinitx";
  e.message.html = `
    <div style="background-color:#0b0f14;padding:32px 16px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;">
      <div style="max-width:520px;margin:0 auto;background-color:#12161d;border:1px solid #232a35;border-radius:16px;overflow:hidden;">
        <div style="padding:28px 32px 20px;text-align:center;border-bottom:1px solid #232a35;">
          <div style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:12px;background-color:rgba(243,186,47,0.12);margin-bottom:12px;">
            <span style="font-size:22px;">&#8383;</span>
          </div>
          <p style="margin:0;color:#f3ba2f;font-size:13px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;">delfinitx</p>
        </div>
        <div style="padding:32px;color:#e6e9ee;">
          <h1 style="margin:0 0 20px;font-size:20px;color:#ffffff;">Welcome to delfinitx</h1>
          <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#aeb6c2;">Dear ${name},</p>
          <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#aeb6c2;">
            Thank you for registering with delfinitx. We're excited to have you on board.
          </p>
          <p style="margin:0 0 24px;font-size:14px;line-height:1.6;color:#aeb6c2;">
            To complete your registration, please verify your email address by clicking the button below:
          </p>
          <div style="text-align:center;margin:0 0 28px;">
            <a href="${link}" style="display:inline-block;background-color:#f3ba2f;color:#141414;font-weight:700;font-size:14px;text-decoration:none;padding:14px 32px;border-radius:10px;">Verify Email</a>
          </div>
          <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#aeb6c2;">
            Once verified, your account will be pending approval from our team. You will receive a confirmation email once your account has been approved.
          </p>
          <p style="margin:0 0 24px;font-size:13px;line-height:1.6;color:#6b7280;">
            If you did not create this account, please ignore this email.
          </p>
          <p style="margin:0;font-size:14px;line-height:1.6;color:#e6e9ee;">
            Best regards,<br />delfinitx Team
          </p>
        </div>
      </div>
    </div>
  `;

  e.next();
}, "users");
