/// <reference path="../pb_data/types.d.ts" />

// Robust, permanent client deletion for the admin dashboard.
//
// The frontend delete (pb.collection('users').delete) proved unreliable in
// practice — records lingered in the database even though they disappeared
// from the dashboard, so their email stayed reserved and blocked new
// sign-ups ("Value must be unique"). This custom route runs with full
// superuser privileges: it verifies the caller is an authenticated admin,
// then hard-deletes the target user together with all of their transactions,
// guaranteeing the record is COMPLETELY removed from the database and the
// email is freed for re-registration.
routerAdd("POST", "/api/admin-delete-user", (e) => {
  const auth = e.auth;
  if (!auth || auth.get("role") !== "admin") {
    return e.json(403, { message: "Solo un amministratore può cancellare i clienti." });
  }

  const body = e.requestInfo().body || {};
  const userId = body.userId;
  if (!userId) {
    return e.json(400, { message: "userId mancante." });
  }

  let target;
  try {
    target = e.app.findRecordById("users", userId);
  } catch (err) {
    // Already gone — treat as success so the dashboard stays consistent.
    return e.json(200, { success: true, deleted: false, message: "Cliente già rimosso." });
  }

  if (target.get("role") === "admin") {
    return e.json(400, { message: "Non è possibile cancellare un account amministratore." });
  }

  const email = target.get("email");

  // Remove any transactions owned by this client first (belt-and-suspenders
  // even though the relation cascades), then delete the user record itself.
  try {
    const txs = e.app.findRecordsByFilter(
      "transactions",
      "owner = {:id}",
      "-created",
      0,
      0,
      { id: userId }
    );
    txs.forEach((t) => {
      try { e.app.delete(t); } catch (_) { /* ignore individual tx errors */ }
    });
  } catch (_) {
    /* no transactions or collection issue — continue to user delete */
  }

  e.app.delete(target);

  return e.json(200, {
    success: true,
    deleted: true,
    email,
    message: "Cliente completamente rimosso dal database.",
  });
});
