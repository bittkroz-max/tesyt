const RECAPTCHA_SECRET_KEY = process.env.RECAPTCHA_SECRET_KEY;

export default async (req, res) => {
	const { token } = req.body ?? {};

	if (!token) {
		return res.status(422).json({ error: 'token is required' });
	}

	if (!RECAPTCHA_SECRET_KEY) {
		throw new Error('RECAPTCHA_SECRET_KEY is not set in apps/api/.env');
	}

	const response = await fetch('https://www.google.com/recaptcha/api/siteverify', {
		method: 'POST',
		headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
		body: new URLSearchParams({
			secret: RECAPTCHA_SECRET_KEY,
			response: token,
		}),
	});

	if (!response.ok) {
		throw new Error(`recaptcha siteverify failed: ${response.status} ${response.statusText}`);
	}

	const data = await response.json();

	if (!data.success) {
		return res.status(200).json({ success: false, errorCodes: data['error-codes'] || [] });
	}

	res.json({ success: true });
};
