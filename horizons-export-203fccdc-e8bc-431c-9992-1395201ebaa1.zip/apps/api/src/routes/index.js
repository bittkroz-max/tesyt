import { Router } from 'express';
import healthCheck from './health-check.js';
import verifyCaptcha from './verify-captcha.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.post('/verify-captcha', verifyCaptcha);

    return router;
};

